#include "main.hpp"
#include "VivifyRuntime.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <string>
#include <string_view>
#include <exception>
#include "HMUI/ViewController.hpp"
#include "UnityEngine/GameObject.hpp"
#include "UnityEngine/Transform.hpp"
#include "UnityEngine/XR/XRSettings.hpp"
#include "bsml/shared/BSML-Lite/Creation/Layout.hpp"
#include "bsml/shared/BSML-Lite/Creation/Settings.hpp"
#include "bsml/shared/BSML/Settings/BSMLSettings.hpp"
#include "custom-types/shared/register.hpp"
#include "scotland2/shared/modloader.h"

static modloader::ModInfo modInfo{MOD_ID, VERSION, 0};

namespace {
constexpr std::string_view kEnableBlitEffectsConfigKey = "enableBlitEffects";
constexpr std::string_view kEnableBeat0FilmgrainConfigKey = "enableBeat0Filmgrain";
constexpr std::string_view kEnableSecondaryDepthCamerasConfigKey = "enableSecondaryDepthCameras";

// The settings page exposes only individual features. Every feature is enabled
// by default and can be disabled independently.
bool gEnableBlitEffects = true;
bool gEnableBeat0Filmgrain = true;
bool gEnableSecondaryDepthCameras = true;

void EnsureConfigObject() {
  auto& doc = getConfig().config;
  if (!doc.IsObject()) {
    doc.SetObject();
  }
}

bool EnsureBoolConfigValue(std::string_view key, bool defaultValue, bool& value) {
  auto& doc = getConfig().config;
  auto it = doc.FindMember(key.data());
  if (it != doc.MemberEnd() && it->value.IsBool()) {
    value = it->value.GetBool();
    return false;
  }

  auto& allocator = doc.GetAllocator();
  value = defaultValue;
  if (it == doc.MemberEnd()) {
    doc.AddMember(rapidjson::Value(key.data(), allocator), rapidjson::Value(defaultValue), allocator);
  } else {
    it->value.SetBool(defaultValue);
  }
  return true;
}

void SetBoolConfigValue(std::string_view key, bool enabled, bool& value) {
  auto& config = getConfig();
  auto& doc = config.config;
  EnsureConfigObject();
  auto& allocator = doc.GetAllocator();
  auto it = doc.FindMember(key.data());
  if (it == doc.MemberEnd()) {
    doc.AddMember(rapidjson::Value(key.data(), allocator), rapidjson::Value(enabled), allocator);
  } else {
    it->value.SetBool(enabled);
  }
  value = enabled;
  config.Write();
}

void RegisterModSettings() {
  BSML::BSMLSettings::get_instance()->TryAddSettingsMenu(
      [](HMUI::ViewController* viewController, bool firstActivation, bool, bool) {
        if (!firstActivation || viewController == nullptr) return;
        auto* container = BSML::Lite::CreateScrollableSettingsContainer(viewController->get_transform());
        if (container == nullptr) return;

        BSML::Lite::CreateToggle(
            container->get_transform(), u"Blit effects", gEnableBlitEffects,
            [](bool value) {
              SetBoolConfigValue(kEnableBlitEffectsConfigKey, value, gEnableBlitEffects);
              Vivify::RefreshIsolationSettings();
            });
        BSML::Lite::CreateToggle(
            container->get_transform(), u"Beat-0 film grain", gEnableBeat0Filmgrain,
            [](bool value) {
              SetBoolConfigValue(kEnableBeat0FilmgrainConfigKey, value, gEnableBeat0Filmgrain);
              Vivify::RefreshIsolationSettings();
            });
        BSML::Lite::CreateToggle(
            container->get_transform(), u"Secondary/depth cameras", gEnableSecondaryDepthCameras,
            [](bool value) {
              SetBoolConfigValue(kEnableSecondaryDepthCamerasConfigKey, value,
                                 gEnableSecondaryDepthCameras);
              Vivify::RefreshIsolationSettings();
            });
      },
      "Vivify", false);
}
}

Configuration &getConfig() {
  static Configuration config(modInfo);
  return config;
}

bool GetMultipassRenderingEnabled() {
  // MULTIPASS_ENABLED selects the two-render-pass shader variant. Quest's
  // SinglePassMultiview mode is value 3 and must use the texture-array shader
  // variant instead; forcing this keyword there makes the two eyes sample the
  // wrong layout and produces rows, duplicates and divergent eye output.
  return UnityEngine::XR::XRSettings::get_enabled() &&
         UnityEngine::XR::XRSettings::get_stereoRenderingMode().value__ == 0;
}

bool IsQuestXrRuntime() {
  return UnityEngine::XR::XRSettings::get_enabled();
}

bool GetDisableBeat0FilmgrainBlit() {
  return !gEnableBeat0Filmgrain;
}

bool GetDisableAllBlits() {
  return !gEnableBlitEffects;
}

bool GetDisableCreateCameraDepth() {
  return !gEnableSecondaryDepthCameras;
}

bool GetQuestCompatibilityMode() {
  return false;
}

bool GetStaggerPrefabPrewarm() {
  return false;
}

float GetImmediatePrefabPrewarmSeconds() {
  return 12.0f;
}

float GetPrefabPrewarmLeadSeconds() {
  return 18.0f;
}

int GetPrefabsPerFrame() {
  return 1;
}

void EnsureConfigDefaults() {
  auto& config = getConfig();
  auto& doc = config.config;
  EnsureConfigObject();

  // Remove every old profile, safety, recovery, tuning and negative-disable key.
  constexpr std::array<std::string_view, 16> obsoleteKeys{
      "multipassRendering", "stereoSafetyMode", "disableBeat0FilmgrainBlit",
      "disableAllBlits", "disableCreateCameraDepth", "questCompatibilityMode",
      "staggerPrefabPrewarm", "questRenderProfile", "immediatePrefabPrewarmSeconds",
      "prefabPrewarmLeadSeconds", "prefabsPerFrame", "fullEffectsBaseline0_5_8",
      "questMultiviewBaseline0_5_9", "enableMultiviewSafety",
      "enablePrefabPrewarming", "vivifyDebugLogging"};
  bool needsWrite = false;
  for (auto key : obsoleteKeys) {
    auto it = doc.FindMember(key.data());
    if (it != doc.MemberEnd()) {
      doc.RemoveMember(it);
      needsWrite = true;
    }
  }

  needsWrite |= EnsureBoolConfigValue(kEnableBlitEffectsConfigKey, true, gEnableBlitEffects);
  needsWrite |= EnsureBoolConfigValue(kEnableBeat0FilmgrainConfigKey, true, gEnableBeat0Filmgrain);
  needsWrite |= EnsureBoolConfigValue(kEnableSecondaryDepthCamerasConfigKey, true,
                                      gEnableSecondaryDepthCameras);

  if (needsWrite) config.Write();
}

MOD_EXTERN_FUNC void setup(CModInfo *info) noexcept {
  *info = modInfo.to_c();
  try {
    getConfig().Load();
    EnsureConfigDefaults();
  } catch (std::exception const& ex) {
    try { PaperLogger.error("Vivify setup failed safely: {}", ex.what()); } catch (...) {}
  } catch (...) {
    try { PaperLogger.error("Vivify setup failed safely with a non-std exception"); } catch (...) {}
  }
}
MOD_EXTERN_FUNC void late_load() noexcept {
  try {
    il2cpp_functions::Init();
    custom_types::Register::AutoRegister();
    RegisterModSettings();
    Vivify::LateLoad();
  } catch (std::exception const& ex) {
    try { PaperLogger.error("Vivify late_load failed safely: {}", ex.what()); } catch (...) {}
  } catch (...) {
    try { PaperLogger.error("Vivify late_load failed safely with a non-std exception"); } catch (...) {}
  }
}
