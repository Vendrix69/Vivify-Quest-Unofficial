#include "VivifyRuntimeInternal.hpp"
#include "VivifyComponents.hpp"
#include "UnityEngine/ParticleSystem.hpp"
#include "GlobalNamespace/PlayerDataModel.hpp"
#include "GlobalNamespace/PlayerData.hpp"
#include "GlobalNamespace/PlayerSpecificSettings.hpp"
#include "UnityEngine/SceneManagement/Scene.hpp"
#include "UnityEngine/SceneManagement/SceneManager.hpp"

namespace Vivify {

namespace {
constexpr int kVideoPrepareWatchdogFrames = 900;
constexpr int kVideoFirstFrameGraceFrames = 120;
constexpr int kVideoRecoveryBackoffFrames = 180;
constexpr int kVideoStallFrames = 300;
constexpr int kVideoDriftCorrectionCooldownFrames = 60;
constexpr float kVideoDriftToleranceSeconds = 0.5f;
constexpr float kVideoAggressiveRecoveryMaxRate = 3.0f;
// Android seeks commonly land on an earlier keyframe. Commit 103 keeps the
// decoder only modestly faster than the song while it is behind. The older +2x
// turbo is especially expensive while the Quest recorder is active and can
// starve MediaCodec badly enough to make catch-up self-defeating. High-speed
// practice gets a 1.00x margin at >125% so 200% practice may briefly run the
// decoder at 3.0x. Quest VideoPlayer already has skipOnDrop enabled, allowing
// intermediate presentation frames to be discarded during this short burst.
// No extra seeks, retries, polling, or decoder restarts are added.
constexpr float kHistoricalVideoCatchupExtraRate = 0.50f;
constexpr float kHistoricalVideoHighSpeedCatchupExtraRate = 1.00f;
constexpr float kHistoricalVideoFullBoostMaxPracticeRate = 1.25f;
constexpr float kHistoricalVideoCatchupMaxRate = 3.00f;
constexpr float kHistoricalVideoCatchupToleranceSeconds = 0.18f;
constexpr int kHistoricalVideoCatchupStablePolls = 3;
// A persistent decoder can fall behind again later when recording or another
// expensive effect starts. Re-arm rate-only convergence without issuing a seek.
constexpr float kHistoricalVideoCatchupRearmDriftSeconds = 0.35f;
constexpr int kHistoricalVideoProbeMaxSamples = 512;
constexpr float kHistoricalVideoProbeTargetStepSeconds = 1.0f / 15.0f;

// Shared material fan-out only needs one rooted property block. Unity copies
// the block in Renderer.SetPropertyBlock, so it can be reused for every video
// follower without per-frame managed allocations.
SafePtr<UnityEngine::MaterialPropertyBlock> gSharedVideoPropertyBlock;

// Quest never routes authored VideoPlayer audio: synchronized Vivify video is
// visual-only in this port and the song/audio clock remains Beat Saber-owned.
// audioOutputMode=None prevents output but Unity documents that disabling each
// track is what actually stops audio decoding. Do it while the player is
// stopped, before Prepare/Play, to save MediaCodec/CPU work.
void DisableVideoAudioDecoding(UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(player) || player->get_isPlaying()) return;
  try {
    uint16_t const tracks = player->get_audioTrackCount();
    for (uint16_t track = 0; track < tracks; ++track) {
      player->EnableAudioTrack(track, false);
    }
  } catch (...) {
    // Some Android backends do not expose track metadata until preparation.
    // audioOutputMode=None remains the safe fallback in that case.
  }
}

// MediaCodec teardown on Quest is asynchronous. Destroying a GameObject that
// still owns a prepared/playing VideoPlayer can race Android's codec/surface
// shutdown with the next practice/restart decoder allocation. Keep normal sync
// behavior untouched; only make owned-decoder destruction explicit and ordered.
void StopVideoPlayerBeforeDestroy(UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(player)) return;
  try {
    player->Stop();
  } catch (...) {
    // Teardown must remain best-effort during scene destruction.
  }
}

bool IsMainMenuSceneActive() {
  auto scene = UnityEngine::SceneManagement::SceneManager::GetActiveScene();
  return scene.get_name() == "MainMenu";
}

UnityEngine::AnimationState* DefaultLegacyAnimationState(
    UnityEngine::Animation* animation) {
  if (!IsManagedAlive(animation)) return nullptr;
  auto clip = animation->get_clip();
  auto* clipPtr = clip.unsafePtr();
  if (!IsManagedAlive(clipPtr)) return nullptr;
  return animation->get_Item(clipPtr->get_name());
}

void SetLegacyAnimationSpeed(UnityEngine::Animation* animation, float speed) {
  auto* state = DefaultLegacyAnimationState(animation);
  if (state != nullptr && UnityEngine::TrackedReference::op_Implicit_bool(state)) {
    state->set_speed(speed);
  }
}

bool HasDecodedVideoOutput(UnityEngine::Video::VideoPlayer* player,
                           bool prepared, std::int64_t& decodedFrame) {
  decodedFrame = -1;
  if (!IsManagedAlive(player) || !prepared) return false;

  auto texture = player->get_texture();
  if (!IsManagedAlive(texture.unsafePtr())) return false;

  // Quest's Android VideoPlayer can keep reporting frame == -1 while its
  // external texture is already valid and visibly advancing. Treat dimensions
  // plus a live texture as healthy output; frame is an optional stall signal.
  decodedFrame = player->get_frame();
  return player->get_width() > 0 && player->get_height() > 0;
}

float DecodedVideoTime(UnityEngine::Video::VideoPlayer* player,
                       std::int64_t decodedFrame) {
  if (!IsManagedAlive(player) || decodedFrame < 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  float const frameRate = player->get_frameRate();
  if (!std::isfinite(frameRate) || frameRate <= 0.001f) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  return static_cast<float>(decodedFrame) / frameRate;
}

float HistoricalVideoRate(float normalRate) {
  if (!std::isfinite(normalRate) || normalRate <= 0.001f) return normalRate;

  float const extraRate =
      normalRate <= kHistoricalVideoFullBoostMaxPracticeRate
          ? kHistoricalVideoCatchupExtraRate
          : kHistoricalVideoHighSpeedCatchupExtraRate;
  return std::max(normalRate,
                  std::min(kHistoricalVideoCatchupMaxRate,
                           normalRate + extraRate));
}

void CachePreparedVideoLength(SyncedVideoPlayer& video, bool prepared) {
  if (!prepared || !IsManagedAlive(video.player) ||
      (std::isfinite(video.cachedLength) && video.cachedLength > 0.0)) {
    return;
  }
  double const length = video.player->get_length();
  if (std::isfinite(length) && length > 0.0) video.cachedLength = length;
}

bool ShouldVideoAdvance(SyncedVideoPlayer const& video,
                        float videoTime, float playbackSpeed) {
  if (!IsManagedAlive(video.player) || playbackSpeed <= 0.001f) return false;
  if (video.looping) return true;

  double const length = video.cachedLength;
  return !std::isfinite(length) || length <= 0.0 ||
         static_cast<double>(videoTime) + 0.1 < length;
}

bool IsAuthoredVideoGameObjectActive(SyncedVideoPlayer const& video) {
  if (!IsManagedAlive(video.authoredPlayer)) return false;
  auto go = video.authoredPlayer->get_gameObject();
  auto* goPtr = go.unsafePtr();
  return IsManagedAlive(goPtr) && goPtr->get_activeInHierarchy();
}

bool SameAuthoredVideoSource(SyncedVideoPlayer const& left,
                             SyncedVideoPlayer const& right) {
  if (!IsManagedAlive(left.authoredPlayer) || !IsManagedAlive(right.authoredPlayer)) {
    return false;
  }
  auto const leftSource = left.authoredPlayer->get_source();
  auto const rightSource = right.authoredPlayer->get_source();
  if (leftSource.value__ != rightSource.value__) return false;

  if (leftSource.value__ == 0) {
    auto leftClip = left.authoredPlayer->get_clip();
    auto rightClip = right.authoredPlayer->get_clip();
    return leftClip.unsafePtr() == rightClip.unsafePtr() &&
           IsManagedAlive(leftClip.unsafePtr());
  }
  auto const leftUrl = ToStdString(left.authoredPlayer->get_url());
  auto const rightUrl = ToStdString(right.authoredPlayer->get_url());
  return !leftUrl.empty() && leftUrl == rightUrl;
}

bool CanShareVideoDecoder(SyncedVideoPlayer const& left,
                          SyncedVideoPlayer const& right) {
  if (&left == &right || left.sharedDecoderFollower || right.sharedDecoderFollower ||
      !left.persistentDecoder || !right.persistentDecoder ||
      !IsManagedAlive(left.player) || !IsManagedAlive(right.player) ||
      !left.playbackStartKnown || !right.playbackStartKnown) {
    return false;
  }
  if (std::abs(left.playbackStartSongTime - right.playbackStartSongTime) > 0.001f) {
    return false;
  }
  if (!SameAuthoredVideoSource(left, right)) return false;
  if (left.looping != right.looping) return false;
  if (std::abs(left.authoredPlayer->get_playbackSpeed() -
               right.authoredPlayer->get_playbackSpeed()) > 0.001f) {
    return false;
  }

  if (left.renderModeValue != right.renderModeValue) return false;

  if (left.renderModeValue ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    // MaterialOverride can fan the same external texture out to independent
    // renderers without an intermediate RenderTexture or Graphics.Blit.
    return IsManagedAlive(left.materialTarget) && IsManagedAlive(right.materialTarget);
  }
  if (left.renderModeValue ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    // A hardware decode is far more expensive on Quest than copying its
    // already-decoded texture to another authored RT. Keep each screen's RT
    // identity intact, but allow equivalent timelines to share one decoder.
    return IsManagedAlive(left.renderTextureTarget) &&
           IsManagedAlive(right.renderTextureTarget);
  }
  return false;
}

int VideoDecoderReadinessScore(SyncedVideoPlayer const& video) {
  if (!IsManagedAlive(video.player)) return -1;
  int score = 0;
  if (video.hasProducedTexture) score += 16;
  if (video.player->get_isPrepared()) score += 8;
  if (video.player->get_isPlaying()) score += 4;
  if (video.requestedPrewarmFrame) score += 2;
  if (IsManagedAlive(video.decoderObject)) score += 1;
  return score;
}

void MakeSharedVideoFollower(SyncedVideoPlayer& follower,
                             SyncedVideoPlayer& leader) {
  if (!CanShareVideoDecoder(follower, leader)) return;
  auto* leaderPlayer = leader.player;
  if (!IsManagedAlive(leaderPlayer)) return;

  if (IsManagedAlive(follower.decoderObject) &&
      follower.decoderObject != leader.decoderObject) {
    StopVideoPlayerBeforeDestroy(follower.player);
    UnityEngine::Object::Destroy(follower.decoderObject);
  }
  follower.player = leaderPlayer;
  follower.decoderObject = nullptr;
  follower.sharedDecoderFollower = true;
  follower.sharedBoundTexture = nullptr;
  follower.sharedRenderTargetAlias =
      follower.renderModeValue == UnityEngine::Video::VideoRenderMode::RenderTexture.value__ &&
      follower.renderTextureTarget == leader.renderTextureTarget;
  follower.preparePending = false;
  follower.needsStartupKick = false;
  follower.requestedPrewarmFrame = true;
  follower.hasProducedTexture = false;
  follower.historicalCatchupActive = false;
  follower.historicalCatchupStablePolls = 0;
  follower.lastAppliedPlaybackSpeed = leader.lastAppliedPlaybackSpeed;
}

void ConsolidateEquivalentVideoDecoders(SyncedObject& synced) {
  synced.videoConsolidationDirty = false;
  auto& videos = synced.videoPlayers;
  for (std::size_t i = 0; i < videos.size(); i++) {
    if (videos[i].sharedDecoderFollower || !videos[i].playbackStartKnown) continue;

    std::vector<std::size_t> group{i};
    for (std::size_t j = i + 1; j < videos.size(); j++) {
      if (videos[j].sharedDecoderFollower) continue;
      if (CanShareVideoDecoder(videos[i], videos[j])) group.push_back(j);
    }
    if (group.size() < 2) continue;

    std::size_t leaderIndex = group.front();
    int bestScore = VideoDecoderReadinessScore(videos[leaderIndex]);
    for (std::size_t index : group) {
      int const score = VideoDecoderReadinessScore(videos[index]);
      if (score > bestScore) {
        bestScore = score;
        leaderIndex = index;
      }
    }

    auto& leader = videos[leaderIndex];
    std::size_t merged = 0;
    for (std::size_t index : group) {
      if (index == leaderIndex) continue;
      MakeSharedVideoFollower(videos[index], leader);
      if (videos[index].sharedDecoderFollower) merged++;
    }
    if (merged > 0) {
      PaperLogger.info(
          "Vivify consolidated {} duplicate Quest video decoder(s) for '{}'",
          merged, IsManagedAlive(leader.authoredPlayer)
                      ? ToStdString(leader.authoredPlayer->get_gameObject()->get_name())
                      : std::string("<video>"));
    }
  }
}

bool IsSharedVideoFollowerRenderable(SyncedVideoPlayer const& video) {
  if (!video.sharedDecoderFollower || !IsManagedAlive(video.authoredPlayer)) return false;
  if (video.renderModeValue == UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    if (!IsManagedAlive(video.materialTarget)) return false;
    auto targetObject = video.materialTarget->get_gameObject();
    auto* targetObjectPtr = targetObject.unsafePtr();
    return video.materialTarget->get_enabled() && IsManagedAlive(targetObjectPtr) &&
           targetObjectPtr->get_activeInHierarchy();
  }
  if (video.renderModeValue == UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    return IsManagedAlive(video.renderTextureTarget) && video.renderTextureTarget->IsCreated();
  }
  return false;
}

bool BindSharedVideoFollowerOutput(SyncedVideoPlayer& video,
                                   UnityEngine::Texture* currentTexture) {
  if (!video.sharedDecoderFollower || !IsManagedAlive(video.player) ||
      !IsManagedAlive(video.authoredPlayer)) {
    return false;
  }
  if (video.renderModeValue == UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    if (!target->IsCreated()) return false;

    if (video.sharedRenderTargetAlias) return true;

    if (!IsManagedAlive(currentTexture)) return false;
    UnityEngine::Graphics::Blit(currentTexture, target);
    video.sharedBoundTexture = currentTexture;
    return true;
  }
  if (video.renderModeValue != UnityEngine::Video::VideoRenderMode::MaterialOverride.value__ ||
      !IsManagedAlive(video.materialTarget)) {
    return false;
  }

  if (!IsManagedAlive(currentTexture)) return false;

  if (!gSharedVideoPropertyBlock) {
    auto* created = UnityEngine::MaterialPropertyBlock::New_ctor();
    if (created != nullptr) gSharedVideoPropertyBlock.emplace(created);
  }
  auto* block = gSharedVideoPropertyBlock ? gSharedVideoPropertyBlock.ptr() : nullptr;
  if (block == nullptr) return false;

  int const propertyId = video.targetMaterialPropertyId;
  block->Clear();
  video.materialTarget->GetPropertyBlock(block);
  block->SetTexture(propertyId, currentTexture);
  video.materialTarget->SetPropertyBlock(block);
  video.sharedBoundTexture = currentTexture;
  return true;
}

float NormalizeVideoTime(SyncedVideoPlayer const& video, float elapsed,
                         bool prepared) {
  if (!IsManagedAlive(video.player) || !prepared || !video.looping) return elapsed;

  double const length = video.cachedLength;
  if (!std::isfinite(length) || length <= 0.0) return elapsed;
  return static_cast<float>(std::fmod(static_cast<double>(elapsed), length));
}

bool EnsureVideoOutputBinding(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;

  if (video.renderModeValue ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetTexture();
      target = targetReference.unsafePtr();
      video.renderTextureTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    player->set_targetTexture(target);
    return target->IsCreated();
  }

  if (video.renderModeValue ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    auto* target = video.materialTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetMaterialRenderer();
      target = targetReference.unsafePtr();
      if (!IsManagedAlive(target)) {
        target = video.authoredPlayer->GetComponent<UnityEngine::Renderer*>();
        if (!IsManagedAlive(target)) {
          target = video.authoredPlayer->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
      }
      video.materialTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    player->set_targetMaterialRenderer(target);
    if (ToStdString(player->get_targetMaterialProperty()).empty()) {
      player->set_targetMaterialProperty(StringW("_MainTex"));
    }
    return true;
  }

  return true;
}

bool IsVideoOutputRenderable(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;
  if (video.renderModeValue ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    // RenderTexture videos do not need their target reassigned every render
    // frame. Only repair/recreate the binding if the cached target disappeared
    // or Unity actually lost the RenderTexture. Startup, first-frame and
    // reactivation paths still deliberately call EnsureVideoOutputBinding to
    // preserve V1's Android external-texture recovery behavior.
    auto* target = video.renderTextureTarget;
    auto boundReference = player->get_targetTexture();
    auto* boundTarget = boundReference.unsafePtr();
    if (!IsManagedAlive(target) || !target->IsCreated() || boundTarget != target) {
      return EnsureVideoOutputBinding(video);
    }
    return true;
  }
  if (video.renderModeValue !=
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    return true;
  }
  // Same principle for MaterialOverride: checking whether the authored target
  // is currently visible must not also issue the same native target assignment
  // every frame. Resolve a lost target on demand, while explicit transition
  // paths below still perform the intentional same-target rebind.
  auto boundReference = player->get_targetMaterialRenderer();
  auto* boundTarget = boundReference.unsafePtr();
  if (!IsManagedAlive(video.materialTarget) || boundTarget != video.materialTarget) {
    if (!EnsureVideoOutputBinding(video) || !IsManagedAlive(video.materialTarget)) {
      return false;
    }
  }
  auto targetObject = video.materialTarget->get_gameObject();
  auto* targetObjectPtr = targetObject.unsafePtr();
  return video.materialTarget->get_enabled() && IsManagedAlive(targetObjectPtr) &&
         targetObjectPtr->get_activeInHierarchy();
}

void ReleaseSyncedVideoPlayer(SyncedVideoPlayer& video, bool restoreAuthoredPlayer) {
  if (restoreAuthoredPlayer && IsManagedAlive(video.authoredPlayer)) {
    video.authoredPlayer->set_enabled(video.authoredPlayerWasEnabled);
  }
  if (IsManagedAlive(video.decoderObject)) {
    StopVideoPlayerBeforeDestroy(video.player);
    UnityEngine::Object::Destroy(video.decoderObject);
  }
  video.player = nullptr;
  video.authoredPlayer = nullptr;
  video.decoderObject = nullptr;
  video.materialTarget = nullptr;
  video.renderTextureTarget = nullptr;
  video.sharedDecoderFollower = false;
  video.sharedBoundTexture = nullptr;
}

void ReleaseSyncedVideos(SyncedObject& synced, bool restoreAuthoredPlayer) {
  for (auto& video : synced.videoPlayers) {
    ReleaseSyncedVideoPlayer(video, restoreAuthoredPlayer);
  }
  synced.videoPlayers.clear();
}

void SetParticleClockSuppressed(SyncedParticleSystem& syncedParticle,
                                bool suppress) {
  auto* particleSystem = syncedParticle.particleSystem;
  if (!IsManagedAlive(particleSystem)) return;

  auto main = particleSystem->get_main();
  if (suppress) {
    if (!syncedParticle.clockSuppressed) {
      // Capture at the transition to a stopped song clock. Animator clips are
      // allowed to key this property every frame, so the current value—not the
      // prefab's original serialized value—is the one that must be restored.
      float const authoredSpeed = main.get_simulationSpeed();
      if (std::isfinite(authoredSpeed)) {
        syncedParticle.authoredSimulationSpeed = authoredSpeed;
      }
      syncedParticle.clockSuppressed = true;
    }
    main.set_simulationSpeed(0.0f);
    return;
  }

  if (syncedParticle.clockSuppressed) {
    main.set_simulationSpeed(syncedParticle.authoredSimulationSpeed);
    syncedParticle.clockSuppressed = false;
  }
}
}

Runtime& Runtime::Instance() {
  static Runtime runtime;
  return runtime;
}

bool Runtime::IsAlive(UnityEngine::Object* object) const {
  return IsManagedAlive(object);
}

bool Runtime::LateLoad() {
  // Vivify calls directly into CustomJSONData and Tracks. Scotland2 can report a
  // dependency as present at the ELF level while its mod init/late_load failed.
  // Continuing in that state turns an install/load-order problem into a native
  // crash during startup or the first gameplay callback. Fail closed instead.
  auto cjdModInfo = CustomJSONData::modInfo.to_c();
  auto tracksModInfo = CModInfo{.id = "Tracks"};
  auto const cjdResult = modloader_require_mod(&cjdModInfo, CMatchType::MatchType_IdOnly);
  auto const tracksResult = modloader_require_mod(&tracksModInfo, CMatchType::MatchType_IdOnly);
  if (cjdResult != CLoadResultEnum::MatchType_Loaded ||
      tracksResult != CLoadResultEnum::MatchType_Loaded) {
    PaperLogger.error(
        "Vivify disabled for this launch because required mods failed to load (CustomJSONData={} Tracks={})",
        static_cast<int>(cjdResult), static_cast<int>(tracksResult));
    return false;
  }

  EnsureBehaviour();
  if (!SongCore::API::Capabilities::IsCapabilityRegistered(kCapability)) {
    SongCore::API::Capabilities::RegisterCapability(kCapability);
  }
  CustomJSONData::CustomEventCallbacks::AddCustomEventCallback(&Runtime::OnCustomEventStatic);
  SongCore::API::LevelSelect::GetLevelWasSelectedEvent() += [](SongCore::API::LevelSelect::LevelWasSelectedEventArgs const& event) {
    try {
      Runtime::Instance().HandleLevelSelected(event);
    } catch (std::exception const& ex) {
      try { PaperLogger.error("Vivify level-selection callback failed safely: {}", ex.what()); } catch (...) {}
    } catch (...) {
      try { PaperLogger.error("Vivify level-selection callback failed safely with a non-std exception"); } catch (...) {}
    }
  };
  return true;
}

void Runtime::EnsureBehaviour() {
  if (_behaviour != nullptr) {
    return;
  }
  auto* gameObject = UnityEngine::GameObject::New_ctor(u"VivifyRuntime");
  UnityEngine::Object::DontDestroyOnLoad(gameObject);
  _behaviour = gameObject->AddComponent<RuntimeBehaviour*>();
  RefreshCameraComponents(false);
}

void Runtime::OnBehaviourDestroyed(RuntimeBehaviour* behaviour) {
  if (_behaviour == behaviour) _behaviour = nullptr;
}

void Runtime::OnCustomEventStatic(GlobalNamespace::BeatmapCallbacksController* callbackController,
                                  CustomJSONData::CustomEventData* customEventData) {
  // Never unwind C++ exceptions through CustomJSONData/IL2CPP callback frames.
  // Event dispatch itself is isolated, but first-event beatmap preparation also
  // performs bundle/prefab/camera work and previously sat outside that guard.
  try {
    Runtime::Instance().HandleCustomEvent(callbackController, customEventData);
  } catch (std::exception const& ex) {
    try { PaperLogger.error("Vivify custom-event callback failed safely: {}", ex.what()); } catch (...) {}
  } catch (...) {
    try { PaperLogger.error("Vivify custom-event callback failed safely with a non-std exception"); } catch (...) {}
  }
}

void Runtime::Update() {
  try {
    if (_isResetting) return;

    // Beatmap callbacks can outlive the gameplay scene by several frames.
    // Leaving authored materials and CameraApplier active during that window
    // attached them to MenuMainCamera and eventually passed a destroyed
    // Material into CommandBuffer.Blit.  The transition reset is deliberately
    // pointer-free, so it is safe even after Unity has begun scene teardown.
    if (_currentBeatmapData != nullptr && IsMainMenuSceneActive()) {
      // Natural song completion can begin dismissing gameplay a few frames
      // before the final authored Vivify events have finished. 0.5.5 kept the
      // live beatmap state through that overlap; immediately resetting here
      // makes the next callback re-prepare/catch-up the entire chart and can
      // blank the final fullscreen pass. Preserve only that genuine end tail.
      if (_naturalCompletionTransitionPending &&
          ShouldDeferNaturalCompletionTransition()) {
        return;
      }
      PaperLogger.info("Vivify detected MainMenu with live beatmap state; applying transition-safe reset");
      ResetRuntime(ResetMode::LateSceneTransition);
      return;
    }

    if (_currentBeatmapData == nullptr) {
      // Bundle video decoding begins in the menu. Keep its readiness gate
      // moving even though no gameplay beatmap is active yet.
      UpdateBundleVideoWarmups();
      // A seek can intentionally tear down live state. Rebuild from the active
      // gameplay callback, but do not probe every menu frame while Unity is
      // still constructing or destroying that callback.
      TryPrepareSelectedBeatmapFromScene();
      if (_currentBeatmapData == nullptr) return;
    }
    if (!_lifecycle.IsActive()) return;

    // Scene transitions can invalidate the cached controller before the
    // beatmap callbacks disappear. Reacquire it instead of permanently
    // disabling Vivify's frame updates for the rest of the level.
    if (!IsAlive(_audioTimeSyncController)) {
      _audioTimeSyncController =
          UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
    }
    if (!IsAlive(_audioTimeSyncController)) return;

    DetectSongRestart();
    // DetectSongRestart can call ResetRuntime(), which clears all beatmap
    // state. Never continue into the update systems after that reset.
    if (_isResetting || _currentBeatmapData == nullptr) return;

    // A malformed map component should not prevent unrelated systems (most
    // importantly Blit expiry) from running. Keep every subsystem isolated
    // and identify the failing one in the log.
    auto runUpdateStep = [this](char const* name, auto&& step) {
      try {
        step();
      } catch (std::exception const& ex) {
        LogThrottledUpdateError(std::string(name) + ": " + ex.what());
      } catch (...) {
        LogThrottledUpdateError(std::string(name) + ": non-std exception");
      }
    };

    runUpdateStep("UpdateStartupPostProcessingEvents",
                  [this]() { UpdateStartupPostProcessingEvents(); });
    runUpdateStep("UpdateMaterialAnimations", [this]() { UpdateMaterialAnimations(); });
    runUpdateStep("UpdateGlobalAnimations", [this]() { UpdateGlobalAnimations(); });
    runUpdateStep("UpdateAnimatorAnimations", [this]() { UpdateAnimatorAnimations(); });
    runUpdateStep("UpdateRenderSettingAnimations",
                  [this]() { UpdateRenderSettingAnimations(); });
    runUpdateStep("UpdateBlitEffects", [this]() { UpdateBlitEffects(); });
    runUpdateStep("UpdateSyncedObjects", [this]() { UpdateSyncedObjects(); });
    runUpdateStep("UpdatePrefabAnimationSpeed",
                  [this]() { UpdatePrefabAnimationSpeed(); });

    runUpdateStep("DeferredSaberVisuals", [this]() {
      int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
      if (_deferredSaberVisualsUntilFrame < 0 ||
          frame < _deferredSaberVisualsUntilFrame) {
        return;
      }
      if (_currentBeatmapData != nullptr && !_isResetting) {
        VIVIFY_DEBUG("Vivify applying deferred/retry saber assignment");
        ApplySaberVisualsToActive();
      }
      _deferredSaberVisualsUntilFrame =
          frame < _saberVisualRetryUntilFrame ? frame + 15 : -1;
    });
    runUpdateStep("UpdateSaberReplacementColors",
                  [this]() { UpdateSaberReplacementColors(); });

    // Refresh last so a Blit dispatched by the startup queue is visible for
    // its intended frame, and so expired effects disable the applier again.
    runUpdateStep("RefreshCameraComponents",
                  [this]() { RefreshCameraComponents(true); });
    runUpdateStep("LogQuestPerformanceHeartbeat",
                  [this]() { LogQuestPerformanceHeartbeat(); });
  } catch (std::exception const& ex) {
    LogThrottledUpdateError(std::string("Runtime::Update: ") + ex.what());
  } catch (...) {
    LogThrottledUpdateError("Runtime::Update: non-std exception");
  }
}

void Runtime::TryPrepareSelectedBeatmapFromScene() {
  if (!_selectedMapHasVivifyRequirement || _selectedLevelPath.empty() ||
      _mainBundle == nullptr || !UnityEngine::Object::op_Implicit_bool(_mainBundle) ||
      _beatmapCallbacksController == nullptr) return;

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame < _nextBeatmapPrepareProbeFrame) return;
  _nextBeatmapPrepareProbeFrame = frame + 15;

  auto* audioController =
      UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  if (!IsAlive(audioController)) return;

  auto* customBeatmapData = GetCustomBeatmapData(_beatmapCallbacksController);
  if (customBeatmapData == nullptr) return;
  float const triggerTime = std::max(0.0f, audioController->get_songTime());
  VIVIFY_DEBUG("Vivify proactive gameplay prepare: customEvents={} songTime={}",
               customBeatmapData->customEventDatas.size(), triggerTime);
  PrepareBeatmap(customBeatmapData, triggerTime, _beatmapCallbacksController);
}

void Runtime::LogThrottledUpdateError(std::string_view what) {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastUpdateErrorFrame < 60) return;
  _lastUpdateErrorFrame = frame;
  PaperLogger.error("Vivify Update threw (frame {}, songTime {}): {} — repeats suppressed ~1s",
                    frame, _songTimeCache, std::string(what));
}

float Runtime::CurrentSongTime() {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame == _songTimeCacheFrame) return _songTimeCache;
  _songTimeCacheFrame = frame;
  // BeatmapCallbacksController is the authoritative clock used to fire the
  // same callbacks that drive notes and cubes. Prefer it over a globally found
  // AudioTimeSyncController so Vivify cannot bind to a stale controller during
  // practice/catch-up or a gameplay-scene transition.
  if (_beatmapCallbacksController != nullptr) {
    _songTimeCache = _beatmapCallbacksController->get_songTime();
    return _songTimeCache;
  }
  if (!IsAlive(_audioTimeSyncController)) {
    _audioTimeSyncController = UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  }
  _songTimeCache = IsAlive(_audioTimeSyncController) ? _audioTimeSyncController->get_songTime() : 0.0f;
  return _songTimeCache;
}

float Runtime::CurrentVisualSongTime() {
  // Continuous AnimatorProperty interpolation should follow the audible song
  // clock. Keep material/global/render-setting clocks on the known-good
  // baseline path because those values can directly drive fullscreen Blits.
  if (!IsAlive(_audioTimeSyncController)) {
    _audioTimeSyncController =
        UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  }
  return IsAlive(_audioTimeSyncController)
             ? _audioTimeSyncController->get_songTime()
             : CurrentSongTime();
}

void Runtime::DetectSongRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  float songTime = CurrentSongTime();
  // Only reset if there's a significant backward jump (>0.25 second) to avoid
  // false positives at song start (0:00) or small timing adjustments
  if (_lastSongTime >= 0.0f && songTime + 0.25f < _lastSongTime) {
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    bool const restartingFromPause =
        _pauseMenuActive && songTime <= 0.25f && _lastSongTime > 1.0f;
    if (restartingFromPause) {
      // The RestartButtonPressed hook normally retires the session before the
      // scene is dismissed. This remains as a live-scene fallback for practice
      // controllers that seek without invoking the pause-menu method.
      VIVIFY_DEBUG("Vivify detected pause-menu restart; retiring the active session");
      ResetRuntime(ResetMode::LiveScene);
      _nextBeatmapPrepareProbeFrame = frame + 90;
    } else {
      ResetRuntime();
    }
    return;
  }
  _lastSongTime = songTime;
}

float Runtime::CurrentBpm() const {
  if (TracksStatic::bpmController) {
    return TracksStatic::bpmController->get_currentBpm();
  }
  return 0.0f;
}

float Runtime::DurationBeatsToSeconds(float durationBeats) const {
  float bpm = CurrentBpm();
  if (bpm <= 0.0f) {
    return 0.0f;
  }
  return (60.0f * durationBeats) / bpm;
}

void Runtime::RegisterSyncedObject(UnityEngine::GameObject* root,
                                   float eventStartSongTime) {
  if (!IsAlive(root)) return;

  // Prewarmed prefabs can register their persistent video decoders many seconds
  // before the actual InstantiatePrefab event. Reuse that prepared decoder when
  // the same instance goes live instead of destroying/recreating it at t=0.
  for (auto& existing : _syncedObjects) {
    if (existing.root != root) continue;
    existing.startTime = eventStartSongTime;
    existing.needsInitialTimelineSample = true;
    existing.nextVideoClockPollFrame = 0;
    existing.videoConsolidationDirty = true;
    // A prewarmed object can become live after the global playback rate was
    // already applied. Force this newly-live component set to receive the
    // current clock-gated rate on the next update.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    for (auto& video : existing.videoPlayers) {
      video.needsStartupKick = true;
      video.nextStartRetryFrame = 0;
      video.hasProducedTexture = false;
      video.lastDecodedFrame = -1;
      // A prewarmed object can become live after practice speed changed.  Rate
      // state is per decoder, so force this video to receive the current rate.
      video.lastAppliedPlaybackSpeed = std::numeric_limits<float>::quiet_NaN();
      video.historicalCatchupStablePolls = 0;
    }
    VIVIFY_DEBUG("Vivify sync: reusing prewarmed synced object '{}' for eventStart={}",
                 ToStdString(root->get_name()), eventStartSongTime);
    return;
  }

  float const currentSongTime = CurrentSongTime();
  float const visualSongTime = CurrentVisualSongTime();
  // BeatmapCallbacksController can trail the audible song clock by roughly half
  // a second on Quest. Prefab Animator/Animation state is visual, so catch it up
  // to the audio clock at registration while keeping video timing on the
  // callback clock below. Never move a visual backwards if the two clocks cross.
  float const initialElapsed = std::max(
      PrefabInitialElapsed(currentSongTime, eventStartSongTime),
      PrefabInitialElapsed(visualSongTime, eventStartSongTime));
  SyncedObject synced;
  synced.root = root;
  // Videos remain tied to the absolute event time; only Animator.Update uses
  // the elapsed time inside the prefab.
  synced.startTime = eventStartSongTime;

  auto videoPlayers = root->GetComponentsInChildren<UnityEngine::Video::VideoPlayer*>(true);
  for (int i = 0; i < videoPlayers.size(); i++) {
    auto* authored = videoPlayers[i];
    if (!IsAlive(authored) || !authored->get_playOnAwake()) continue;

    auto const authoredRenderMode = authored->get_renderMode();
    UnityEngine::Renderer* materialTarget = nullptr;
    UnityEngine::RenderTexture* renderTextureTarget = nullptr;
    if (authoredRenderMode.value__ ==
        UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
      auto targetReference = authored->get_targetMaterialRenderer();
      materialTarget = targetReference.unsafePtr();
      if (!IsAlive(materialTarget)) {
        materialTarget = authored->GetComponent<UnityEngine::Renderer*>();
        if (!IsAlive(materialTarget)) {
          materialTarget = authored->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
        if (IsAlive(materialTarget)) {
          authored->set_targetMaterialRenderer(materialTarget);
          if (ToStdString(authored->get_targetMaterialProperty()).empty()) {
            authored->set_targetMaterialProperty(StringW("_MainTex"));
          }
          PaperLogger.info(
              "Vivify repaired embedded VideoPlayer target: object='{}' renderer='{}' property='{}'",
              ToStdString(authored->get_gameObject()->get_name()),
              ToStdString(materialTarget->get_gameObject()->get_name()),
              ToStdString(authored->get_targetMaterialProperty()));
        } else {
          PaperLogger.warn(
              "Vivify embedded VideoPlayer has no MaterialOverride renderer: object='{}'",
              ToStdString(authored->get_gameObject()->get_name()));
        }
      }
    } else if (authoredRenderMode.value__ ==
               UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
      auto targetReference = authored->get_targetTexture();
      renderTextureTarget = targetReference.unsafePtr();
      if (IsAlive(renderTextureTarget)) {
        if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
      } else {
        PaperLogger.warn(
            "Vivify embedded VideoPlayer has no RenderTexture target: object='{}'",
            ToStdString(authored->get_gameObject()->get_name()));
      }
    }

    SyncedVideoPlayer video;
    video.authoredPlayer = authored;
    video.player = authored;
    video.materialTarget = materialTarget;
    video.renderTextureTarget = renderTextureTarget;
    video.authoredPlayerWasEnabled = authored->get_enabled();
    video.renderModeValue = authoredRenderMode.value__;
    video.looping = authored->get_isLooping();
    if (video.renderModeValue == UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
      auto property = authored->get_targetMaterialProperty();
      if (ToStdString(property).empty()) property = StringW("_MainTex");
      video.targetMaterialPropertyId = UnityEngine::Shader::PropertyToID(property);
    }

    // Unity VideoPlayer preparation does not progress on an inactive prefab.
    // Move both MaterialOverride and RenderTexture playback to an always-active
    // decoder. Embedded clips can adopt the decoder that was already warmed
    // while the song was selected in the menu.
    bool const supportsPersistentOutput =
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::MaterialOverride.value__ &&
         IsAlive(materialTarget)) ||
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::RenderTexture.value__ &&
         IsAlive(renderTextureTarget));
    if (supportsPersistentOutput && IsManagedAlive(_behaviour)) {
      UnityEngine::GameObject* decoderObject = nullptr;
      UnityEngine::Video::VideoPlayer* decoder = nullptr;
      bool adoptedWarmup = false;
      if (authored->get_source().value__ == 0) {
        auto clipReference = authored->get_clip();
        decoder = ClaimBundleVideoWarmup(clipReference.unsafePtr(), decoderObject);
        adoptedWarmup = IsAlive(decoder) && IsAlive(decoderObject);
      }

      if (!adoptedWarmup) {
        decoderObject = UnityEngine::GameObject::New_ctor(u"VivifyVideoDecoder");
      }
      if (IsAlive(decoderObject)) {
        // Never deactivate an adopted warmup: on Quest that can retire the
        // MediaCodec instance we are deliberately carrying into gameplay.
        if (!adoptedWarmup) decoderObject->SetActive(false);
        auto behaviourObject = _behaviour->get_gameObject();
        auto* behaviourObjectPtr = behaviourObject.unsafePtr();
        if (IsAlive(behaviourObjectPtr)) {
          decoderObject->get_transform()->SetParent(behaviourObjectPtr->get_transform(), false);
        }
        if (!adoptedWarmup) {
          decoder = decoderObject->AddComponent<UnityEngine::Video::VideoPlayer*>();
        }
        if (IsAlive(decoder)) {
          if (decoder->get_isPlaying()) decoder->Pause();
          if (!adoptedWarmup) {
            // Setting clip/url also selects the matching VideoSource in Unity.
            if (authored->get_source().value__ == 0) {
              decoder->set_clip(authored->get_clip());
            } else {
              decoder->set_url(authored->get_url());
            }
          }
          decoder->set_renderMode(authoredRenderMode);
          if (authoredRenderMode.value__ ==
              UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
            decoder->set_targetMaterialRenderer(materialTarget);
            auto property = authored->get_targetMaterialProperty();
            if (ToStdString(property).empty()) property = StringW("_MainTex");
            decoder->set_targetMaterialProperty(property);
          } else {
            if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
            decoder->set_targetTexture(renderTextureTarget);
          }
          auto audioOutputMode = decoder->get_audioOutputMode();
          audioOutputMode.value__ = 0;  // VideoAudioOutputMode::None without linking enum statics.
          decoder->set_audioOutputMode(audioOutputMode);
          DisableVideoAudioDecoding(decoder);
          decoder->set_playOnAwake(false);
          decoder->set_waitForFirstFrame(true);
          decoder->set_isLooping(video.looping);
          decoder->set_skipOnDrop(true);
          decoderObject->SetActive(true);

          if (authored->get_isPlaying()) authored->Pause();
          authored->set_playOnAwake(false);
          authored->set_enabled(false);

          video.player = decoder;
          video.decoderObject = decoderObject;
          video.persistentDecoder = true;
          EnsureVideoOutputBinding(video);
          PaperLogger.info(
              "Vivify {} persistent Quest video decoder: object='{}' output='{}' target='{}' prepared={}",
              adoptedWarmup ? "adopted menu-warmed" : "created",
              ToStdString(authored->get_gameObject()->get_name()),
              authoredRenderMode.value__ ==
                      UnityEngine::Video::VideoRenderMode::RenderTexture.value__
                  ? "RenderTexture"
                  : "MaterialOverride",
              IsAlive(renderTextureTarget)
                  ? ToStdString(renderTextureTarget->get_name())
                  : (IsAlive(materialTarget)
                         ? ToStdString(materialTarget->get_gameObject()->get_name())
                         : std::string("<missing>")),
              decoder->get_isPrepared());
        } else {
          StopVideoPlayerBeforeDestroy(decoder);
          UnityEngine::Object::Destroy(decoderObject);
        }
      }
    }

    auto* vp = video.player;
    if (!IsAlive(vp)) continue;
    if (!video.persistentDecoder) {
      if (vp->get_isPlaying()) vp->Pause();
      vp->set_playOnAwake(false);
      vp->set_skipOnDrop(true);
    }

    video.needsStartupKick = true;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    video.nextStartRetryFrame = frame;
    video.nextOutputRecoveryFrame = frame;
    video.lastDecodedFrameAdvanceFrame = frame;
    synced.videoPlayers.emplace_back(video);
  }

  float initialSyncSpeed = 0.0f;
  if (!_pauseMenuActive && _syncClockHasAdvanced && IsManagedAlive(_audioTimeSyncController)) {
    float const authoredSpeed = _audioTimeSyncController->get_timeScale();
    float const clockDerivedSpeed =
        std::isfinite(_lastAppliedSyncSpeed) && _lastAppliedSyncSpeed > 0.0f
            ? _lastAppliedSyncSpeed
            : authoredSpeed;
    if (std::isfinite(clockDerivedSpeed) && clockDerivedSpeed > 0.0f) {
      initialSyncSpeed = clockDerivedSpeed;
    }
  }

  auto animators = root->GetComponentsInChildren<UnityEngine::Animator*>(true);
  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    animators[i]->set_updateMode(UnityEngine::AnimatorUpdateMode::Normal);
    // Vivify's authored environment animations are song-timed, not visibility-
    // timed. In normal gameplay a large note/custom-model renderer can make a
    // prefab briefly fail Unity's renderer-visibility culling while Zen mode
    // never does. Never let Animator culling stop the authored timeline.
    animators[i]->set_cullingMode(UnityEngine::AnimatorCullingMode::AlwaysAnimate);
  }

  // A random/practice start can instantiate a prefab after its authored
  // VideoPlayer GameObject was enabled earlier in the animation. Prefab event
  // time is therefore not necessarily video time-zero. Probe the animation only
  // when we actually need historical state, keep the sample count bounded, and
  // never drive a live decoder during the probe (playOnAwake is already false).
  bool historicalVideoProbeRan = false;
  if (initialElapsed > 0.05f && !synced.videoPlayers.empty()) {
    historicalVideoProbeRan = true;
    std::vector<float> firstActiveOffsets(synced.videoPlayers.size(), -1.0f);

    if (animators.size() == 0) {
      // With no Animator there is no delayed authored activation to discover.
      for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
        if (IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
          firstActiveOffsets[videoIndex] = 0.0f;
        }
      }
    } else {
      // Rebind once, then advance monotonically to the requested historical
      // pose. Repeated backward/forward Rebind probing corrupted complex
      // Animator state machines on Quest (Teto teleporting on random starts).
      for (int i = 0; i < animators.size(); i++) {
        if (!IsAlive(animators[i])) continue;
        animators[i]->Rebind();
        animators[i]->Update(0.0f);
      }

      for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
        if (IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
          firstActiveOffsets[videoIndex] = 0.0f;
        }
      }

      int const sampleCount = std::max(1, std::min(
          kHistoricalVideoProbeMaxSamples,
          static_cast<int>(std::ceil(initialElapsed / kHistoricalVideoProbeTargetStepSeconds))));
      float previousSample = 0.0f;
      for (int sampleIndex = 1; sampleIndex <= sampleCount; sampleIndex++) {
        float const sampleTime =
            initialElapsed * static_cast<float>(sampleIndex) / static_cast<float>(sampleCount);
        float const delta = std::max(0.0f, sampleTime - previousSample);
        for (int i = 0; i < animators.size(); i++) {
          if (IsAlive(animators[i])) animators[i]->Update(delta);
        }
        for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
          if (firstActiveOffsets[videoIndex] < 0.0f &&
              IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
            firstActiveOffsets[videoIndex] = sampleTime;
          }
        }
        previousSample = sampleTime;
      }
      // The final sample is exactly initialElapsed, so the live Animator graph
      // is already in the requested pose without another destructive Rebind.
    }

    for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
      float const activationOffset = firstActiveOffsets[videoIndex];
      if (activationOffset < 0.0f || activationOffset > initialElapsed + 0.001f) continue;
      auto& video = synced.videoPlayers[videoIndex];
      video.playbackStartKnown = true;
      video.playbackStartSongTime = eventStartSongTime + activationOffset;
      video.playbackTimelineStarted = currentSongTime + 0.001f >= video.playbackStartSongTime;
      video.needsStartupKick = true;
      float const historicalVideoTime =
          std::max(0.0f, currentSongTime - video.playbackStartSongTime);
      video.historicalCatchupActive =
          video.persistentDecoder && video.playbackTimelineStarted &&
          historicalVideoTime > kHistoricalVideoCatchupToleranceSeconds;
      video.historicalCatchupStablePolls = 0;
      VIVIFY_DEBUG(
          "Vivify sync: historical video activation recovered offset={} eventStart={} videoStart={} currentSongTime={}",
          activationOffset, eventStartSongTime, video.playbackStartSongTime, currentSongTime);
    }
  }

  // Historical/practice registration has already recovered each authored
  // video's real activation time. Collapse only players that are now proven to
  // be the same source on the same timeline. Normal starts are consolidated
  // later as soon as those start times latch.
  ConsolidateEquivalentVideoDecoders(synced);

  // Do not reserve MediaCodec for followers that were just proven redundant.
  // This is especially important on a historical/random start where all video
  // origins are known immediately: duplicates are destroyed before Prepare can
  // allocate additional codec resources.
  int const videoPrepareFrame = static_cast<int>(UnityEngine::Time::get_frameCount());
  for (auto& video : synced.videoPlayers) {
    if (video.sharedDecoderFollower || !IsManagedAlive(video.player)) continue;
    if (!video.player->get_isPrepared()) {
      video.player->Prepare();
      video.preparePending = true;
      video.nextPrepareRetryFrame = videoPrepareFrame + kVideoPrepareWatchdogFrames;
    }
  }

  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    if (initialElapsed > 0.0f && !historicalVideoProbeRan) {
      animators[i]->Update(initialElapsed);
    }
    // Freeze the exact catch-up pose until the authoritative song clock is seen
    // moving. This removes practice-load drift between Zen and normal gameplay.
    animators[i]->set_speed(initialSyncSpeed);
    synced.animators.emplace_back(animators[i]);
  }
  auto legacyAnimations = root->GetComponentsInChildren<UnityEngine::Animation*>(true);
  for (int i = 0; i < legacyAnimations.size(); i++) {
    auto* animation = legacyAnimations[i];
    if (!IsAlive(animation) || !animation->get_playAutomatically()) continue;
    auto* state = DefaultLegacyAnimationState(animation);
    if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;

    // Unity's legacy Animation clock is independent from AudioTimeSyncController.
    // Dynasty's lyrics and environment prefabs use this component rather than
    // Animator, so sample the authored clip at the actual practice/song time.
    if (initialElapsed > 0.0f) {
      state->set_time(initialElapsed);
      animation->Sample();
    }
    state->set_speed(initialSyncSpeed);
    synced.legacyAnimations.emplace_back(animation);
  }
  auto particleSystems = root->GetComponentsInChildren<UnityEngine::ParticleSystem*>(true);
  for (int i = 0; i < particleSystems.size(); i++) {
    if (!IsAlive(particleSystems[i])) continue;
    auto main = particleSystems[i]->get_main();
    SyncedParticleSystem syncedParticle{
        .particleSystem = particleSystems[i],
        .authoredSimulationSpeed = main.get_simulationSpeed(),
        .clockSuppressed = false,
    };
    SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);
    synced.particleSystems.emplace_back(syncedParticle);
  }

  if (!synced.videoPlayers.empty() || !synced.animators.empty() ||
      !synced.legacyAnimations.empty() || !synced.particleSystems.empty()) {
    VIVIFY_DEBUG("Vivify sync: registered '{}' with {} video / {} animator / {} legacy animation / {} particle component(s), eventStart={} songTime={} initialElapsed={}",
                 IsAlive(root) ? ToStdString(root->get_name()) : std::string("?"),
                 synced.videoPlayers.size(), synced.animators.size(),
                 synced.legacyAnimations.size(), synced.particleSystems.size(),
                 eventStartSongTime, currentSongTime, initialElapsed);
    _syncedObjects.emplace_back(std::move(synced));
    // A newly registered animator/particle system must receive the current
    // practice speed even if that speed did not change this frame.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  }
}

void Runtime::UpdatePrefabAnimationSpeed() {
  if (_syncedObjects.empty()) {
    bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
    float const songTime = controllerUnavailable ? -1.0f : CurrentVisualSongTime();
    float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
    // Observe the audible clock even before the first synchronized prefab is
    // spawned. The callback controller trails the rendered/audio timeline on
    // Quest and was the source of the persistent ~0.5 s prefab-animation lag.
    (void) ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                              _lastVisualSyncSongTime, songTime, timeScale,
                              _syncClockStallFrames, _syncClockHasAdvanced);
    if (!controllerUnavailable) _lastVisualSyncSongTime = songTime;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    return;
  }

  bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
  float const songTime = controllerUnavailable ? -1.0f : CurrentVisualSongTime();
  float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
  float const gatedRate = ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                                              _lastVisualSyncSongTime, songTime, timeScale,
                                              _syncClockStallFrames,
                                              _syncClockHasAdvanced);
  float const speed = SongDeltaSyncRate(
      gatedRate, _lastVisualSyncSongTime, songTime,
      UnityEngine::Time::get_deltaTime(), _lastAppliedSyncSpeed);
  if (!controllerUnavailable) _lastVisualSyncSongTime = songTime;

  if (!MeaningfulRateChange(_lastAppliedSyncSpeed, speed)) return;
  _lastAppliedSyncSpeed = speed;

  auto drive = [speed](std::vector<UnityEngine::Animator*> const& animators,
                       std::vector<UnityEngine::Animation*> const& legacyAnimations,
                       std::vector<SyncedParticleSystem>& particleSystems) {
    for (auto* animator : animators) {
      if (IsManagedAlive(animator)) animator->set_speed(speed);
    }
    for (auto* animation : legacyAnimations) {
      SetLegacyAnimationSpeed(animation, speed);
    }
    for (auto& particleSystem : particleSystems) {
      // Animator-authored ParticleSystem speed curves own the running value.
      // Vivify only suppresses/restores them at song-clock stop transitions.
      SetParticleClockSuppressed(particleSystem, speed <= 0.0f);
    }
  };
  for (auto& synced : _syncedObjects) {
    drive(synced.animators, synced.legacyAnimations, synced.particleSystems);
  }
}

void Runtime::LogQuestPerformanceHeartbeat() {
  if (!GetVivifyDebugLogging()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastQuestPerformanceFrame < 900) return;
  _lastQuestPerformanceFrame = frame;

  std::size_t syncedVideoCount = 0;
  std::size_t playingVideoCount = 0;
  for (auto const& synced : _syncedObjects) {
    syncedVideoCount += synced.videoPlayers.size();
    for (auto const& video : synced.videoPlayers) {
      if (IsManagedAlive(video.player) && video.player->get_isPlaying()) {
        playingVideoCount++;
      }
    }
  }
  std::size_t liveWarmupCount = 0;
  std::size_t playingWarmupCount = 0;
  for (auto const& warmup : _bundleVideoWarmups) {
    if (!IsManagedAlive(warmup.player)) continue;
    liveWarmupCount++;
    if (warmup.player->get_isPlaying()) playingWarmupCount++;
  }

  PaperLogger.info(
      "Vivify Quest perf window: frame={} midCacheHits={} midRebuilds={} imageBlits={} imageCommandBufferCreates={} noteRefreshEvents={} noteRefreshCandidates={} prefabLookupRebuilds={} synced={} livePrefabs={} videos[synced={} playing={} warmups={} warmPlaying={}] replacements[note={} saber={} debris={}] declaredTextures={} secondaryCameras={}",
      frame, _midCommandBufferCacheHits, _midCommandBufferRebuilds,
      _imageBlitExecutions, _imageCommandBufferCreates, _noteRefreshEvents,
      _noteRefreshCandidates, _assignedPrefabLookupRebuilds, _syncedObjects.size(),
      _livePrefabs.size(), syncedVideoCount, playingVideoCount,
      liveWarmupCount, playingWarmupCount,
      _noteReplacements.size(), _saberReplacements.size(),
      _debrisReplacements.size(), _declaredTextures.size(), _secondaryCameras.size());
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
}

void Runtime::UnregisterSyncedObject(UnityEngine::GameObject* root) {
  for (auto& synced : _syncedObjects) {
    if (synced.root == root) ReleaseSyncedVideos(synced, false);
  }
  _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                      [root](SyncedObject const& synced) { return synced.root == root; }),
                       _syncedObjects.end());
}

void Runtime::UpdateSyncedObjects() {
  if (_syncedObjects.empty()) {
    // Keep the protected video/seek clock current even while no video-bearing
    // prefab is live. Animation synchronization now has its own audio-clock
    // sample and must no longer advance this callback-clock state indirectly.
    if (IsManagedAlive(_audioTimeSyncController)) {
      _lastSyncSongTime = CurrentSongTime();
    }
    return;
  }
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  // Explicit DestroyObject paths unregister immediately. This cadence is only
  // a safety net for prefabs destroyed by their own animation/scripts, so a
  // full managed-object validity pass is unnecessary on every render frame.
  if (frame >= _nextSyncedObjectPurgeFrame) {
    _nextSyncedObjectPurgeFrame = frame + 30;
    for (auto& synced : _syncedObjects) {
      if (!IsManagedAlive(synced.root)) ReleaseSyncedVideos(synced, false);
    }
    _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                        [](SyncedObject const& synced) { return !IsManagedAlive(synced.root); }),
                         _syncedObjects.end());
  }
  if (_syncedObjects.empty()) {
    if (IsManagedAlive(_audioTimeSyncController)) {
      _lastSyncSongTime = CurrentSongTime();
    }
    return;
  }

  bool const paused = _pauseMenuActive || !IsManagedAlive(_audioTimeSyncController);
  float const songTime = IsManagedAlive(_audioTimeSyncController) ? CurrentSongTime() : 0.0f;
  float const playbackSpeed = IsManagedAlive(_audioTimeSyncController)
                                  ? _audioTimeSyncController->get_timeScale()
                                  : 0.0f;
  // VideoPlayer exposes a seekable time directly, but Unity's legacy
  // AnimationState does not.  Re-sample captions/environment clips on the
  // first live frame and after a real timeline jump (practice start, seek or
  // restart) so they follow the same absolute song clock as video and notes.
  float const unscaledDelta = std::max(1.0f / 240.0f, UnityEngine::Time::get_unscaledDeltaTime());
  float const expectedForwardAdvance = std::max(0.0f, playbackSpeed) * unscaledDelta;
  float const forwardJumpTolerance =
      std::max(0.5f, expectedForwardAdvance * 4.0f + 0.25f);
  bool const timelineJumped =
      _lastSyncSongTime >= 0.0f &&
      (songTime + 0.25f < _lastSyncSongTime ||
       songTime > _lastSyncSongTime + forwardJumpTolerance);

  bool const heartbeat = [&]() {
    if (!GetVivifyDebugLogging()) return false;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    if (frame - _lastSyncHeartbeatFrame < 120) return false;
    _lastSyncHeartbeatFrame = frame;
    return true;
  }();

  for (auto& synced : _syncedObjects) {
    // A normal start learns authored video origins lazily from activation. Once
    // two screens have latched the same origin, release duplicate MediaCodec
    // instances before doing any more decoder work.
    if (synced.videoConsolidationDirty) ConsolidateEquivalentVideoDecoders(synced);
    float const animationTime = std::max(0.0f, songTime - synced.startTime);
    if (synced.needsInitialTimelineSample || timelineJumped) {
      for (auto* animation : synced.legacyAnimations) {
        auto* state = DefaultLegacyAnimationState(animation);
        if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;
        state->set_time(animationTime);
        animation->Sample();
      }
      synced.needsInitialTimelineSample = false;
      if (timelineJumped) {
        VIVIFY_DEBUG("Vivify sync: sampled legacy animation timeline at songTime={} startTime={} elapsed={}",
                     songTime, synced.startTime, animationTime);
      }
    }
    bool const pollVideoClock = timelineJumped || heartbeat ||
                                frame >= synced.nextVideoClockPollFrame;
    if (pollVideoClock) synced.nextVideoClockPollFrame = frame + 6;
    for (auto& video : synced.videoPlayers) {
      auto* vp = video.player;
      if (!IsManagedAlive(vp)) continue;

      // The real video origin is the first stable authored GameObject activation,
      // not the parent InstantiatePrefab event. This is what keeps normal Teto
      // starts correct and also lets a historical/practice start seek once to the
      // same absolute decoder position.
      if (!video.playbackStartKnown && songTime + 0.001f >= synced.startTime) {
        bool const authoredActive = IsAuthoredVideoGameObjectActive(video);
        if (authoredActive) {
          if (video.firstActiveObservedFrame < 0) {
            video.firstActiveObservedFrame = frame;
            video.firstActiveObservedSongTime = songTime;
          } else if (frame > video.firstActiveObservedFrame) {
            video.playbackStartKnown = true;
            video.playbackStartSongTime = video.firstActiveObservedSongTime;
            video.playbackTimelineStarted = true;
            synced.videoConsolidationDirty = true;
            video.needsStartupKick = true;
            video.nextStartRetryFrame = frame;
            video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
            VIVIFY_DEBUG(
                "Vivify sync: latched authored video start at songTime={} prefabStart={}",
                video.playbackStartSongTime, synced.startTime);
          }
        } else {
          video.firstActiveObservedFrame = -1;
        }
      }

      if (video.sharedDecoderFollower) {
        video.playbackTimelineStarted =
            video.playbackStartKnown && songTime + 0.001f >= video.playbackStartSongTime;
        if (!paused && video.playbackTimelineStarted) {
          bool const targetRenderable = IsSharedVideoFollowerRenderable(video);
          auto textureReference = vp->get_texture();
          auto* currentTexture = textureReference.unsafePtr();
          bool const textureChanged = IsManagedAlive(currentTexture) &&
                                      currentTexture != video.sharedBoundTexture;
          bool const renderTextureFollower =
              video.renderModeValue ==
              UnityEngine::Video::VideoRenderMode::RenderTexture.value__;
          // Separate RenderTexture followers need a fresh GPU copy for every
          // presented frame. MaterialOverride followers only rebind when the
          // external texture object changes or the renderer reappears.
          if (renderTextureFollower ||
              (targetRenderable && !video.wasRenderable) || textureChanged ||
              (!video.hasProducedTexture && pollVideoClock)) {
            video.hasProducedTexture = BindSharedVideoFollowerOutput(video, currentTexture);
          }
          video.wasRenderable = targetRenderable;
        } else {
          video.wasRenderable = false;
        }
        // Never Play/Pause/Seek/rate-change a shared player from a follower.
        // The leader owns the one physical MediaCodec clock.
        continue;
      }

      // One native prepared-state read per physical decoder per frame. The old
      // path re-read the same VideoPlayer property in normalization, readiness
      // checks and debug output, multiplying IL2CPP/native traffic on maps with
      // many screens without changing any synchronization decision.
      bool const decoderPrepared = vp->get_isPrepared();
      if (video.looping || pollVideoClock) CachePreparedVideoLength(video, decoderPrepared);

      bool const shouldTimelineRun =
          video.playbackStartKnown && songTime + 0.001f >= video.playbackStartSongTime;
      if (shouldTimelineRun != video.playbackTimelineStarted) {
        video.playbackTimelineStarted = shouldTimelineRun;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
        if (!shouldTimelineRun) {
          if (vp->get_isPlaying()) vp->Pause();
          if (decoderPrepared) vp->set_time(0.0);
          video.requestedPrewarmFrame = false;
          video.historicalCatchupActive = false;
          video.historicalCatchupStablePolls = 0;
        }
      }

      float const rawVideoTime =
          video.playbackStartKnown
              ? std::max(0.0f, songTime - video.playbackStartSongTime)
              : 0.0f;
      float const videoTime = NormalizeVideoTime(video, rawVideoTime, decoderPrepared);
      if (timelineJumped && video.persistentDecoder &&
          video.playbackTimelineStarted &&
          videoTime > kHistoricalVideoCatchupToleranceSeconds) {
        // One controlled reposition happens below. The temporary faster rate
        // then decodes forward from Android's preceding keyframe.
        video.historicalCatchupActive = true;
        video.historicalCatchupStablePolls = 0;
      }
      if (paused) {
        if (vp->get_isPlaying()) {
          VIVIFY_DEBUG("Vivify sync: pausing video (songTime={})", songTime);
          vp->Pause();
        }
        video.needsStartupKick = true;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.nextDriftCorrectionFrame = 0;
        video.historicalCatchupStablePolls = 0;
        continue;
      }
      // Keep preparation warm even while an authored animation has the video
      // screen hidden. That way a later section does not pay decoder startup
      // latency on the first visible frame.
      if (!decoderPrepared) {
        if (!video.preparePending || frame >= video.nextPrepareRetryFrame) {
          VIVIFY_DEBUG("Vivify sync: starting/retrying video Prepare after watchdog (songTime={} videoTime={})",
                       songTime, videoTime);
          vp->Prepare();
          video.preparePending = true;
          video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
        }
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        continue;
      }
      video.preparePending = false;
      video.nextPrepareRetryFrame = 0;

      // Do not touch Android playback-rate state until Prepare has completed.
      // The old path could call the native setter on a newly-created decoder
      // while MediaCodec was still being constructed, which is precisely the
      // fragile first/second-level window seen after changing practice speed.
      // Commit 103 keeps catch-up cheap enough to coexist with Quest recording.
      // The old +2x turbo could make a 1.0x song ask MediaCodec for 3.0x video,
      // while Commit 102 still polled catch-up state every render frame. Use a
      // small bounded rate advantage instead; the state remains active until
      // convergence rather than expiring on a wall-clock deadline.
      float const requestedVideoRate =
          video.historicalCatchupActive
              ? HistoricalVideoRate(playbackSpeed)
              : playbackSpeed;
      if (MeaningfulRateChange(video.lastAppliedPlaybackSpeed, requestedVideoRate)) {
        try {
          vp->set_playbackSpeed(requestedVideoRate);
          video.lastAppliedPlaybackSpeed = requestedVideoRate;
        } catch (...) {
          // Leave the rate dirty so a later prepared frame can retry without
          // turning this into a pause/seek/play loop.
        }
      }

      if (video.persistentDecoder) {
        if (timelineJumped && video.playbackTimelineStarted) {
          video.needsStartupKick = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
        }

        // Prefab prewarming may happen up to ~18 seconds before the event. The
        // proxy is active even though the authored prefab is not, so force one
        // paused frame at t=0 to warm MediaCodec and its external texture.
        bool const beforeVideoStart = !video.playbackTimelineStarted;
        if (beforeVideoStart) {
          if (!video.requestedPrewarmFrame) {
            vp->set_time(0.0);
            // Pause alone does not ask MediaCodec for a frame. Let the hidden
            // proxy decode until frame 0 is real, then freeze it below.
            vp->Play();
            video.requestedPrewarmFrame = true;
            video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
            video.nextOutputRecoveryFrame =
                frame + kVideoRecoveryBackoffFrames;
            video.lastDecodedFrame = -1;
            video.lastDecodedFrameAdvanceFrame = frame;
            VIVIFY_DEBUG("Vivify sync: primed persistent video decoder before event start={}",
                         synced.startTime);
          }
          // Once prewarming has yielded a real frame, leave the hidden decoder
          // frozen. Re-reading its native texture/frame state every render
          // frame only adds IL2CPP traffic and cannot improve readiness.
          if (video.hasProducedTexture) continue;
          std::int64_t decodedFrame = -1;
          if (HasDecodedVideoOutput(vp, decoderPrepared, decodedFrame)) {
            if (!video.hasProducedTexture) {
              EnsureVideoOutputBinding(video);
              video.hasProducedTexture = true;
              video.lastDecodedFrame = decodedFrame;
              video.lastDecodedFrameAdvanceFrame = frame;
              if (vp->get_isPlaying()) vp->Pause();
              vp->set_time(0.0);
            }
          } else if (frame >= video.outputGraceUntilFrame &&
                     frame >= video.nextOutputRecoveryFrame) {
            if (vp->get_isPlaying()) vp->Pause();
            vp->set_time(0.0);
            vp->Play();
            video.outputGraceUntilFrame =
                frame + kVideoFirstFrameGraceFrames;
            video.nextOutputRecoveryFrame =
                frame + kVideoRecoveryBackoffFrames;
            VIVIFY_DEBUG("Vivify sync: prewarm decoder still has no decoded frame; retrying locally");
          }
          continue;
        }

        // Start the decoder according to the song clock even if its target
        // renderer is currently hidden. This is the key section-to-section fix:
        // later screens reveal a decoder that has already been running.
        if (video.needsStartupKick) {
          EnsureVideoOutputBinding(video);
          if (vp->get_isPlaying()) vp->Pause();
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.needsStartupKick = false;
          video.requestedPrewarmFrame = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          synced.nextVideoClockPollFrame = frame + 2;
          VIVIFY_DEBUG("Vivify sync: started persistent decoder (songTime={} videoTime={})",
                       songTime, videoTime);
        }

        bool const targetRenderable = IsVideoOutputRenderable(video);
        if (targetRenderable && !video.wasRenderable) {
          // The decoder never stopped while hidden, so reappearing sections
          // only need their output binding refreshed. Do not restart.
          EnsureVideoOutputBinding(video);
          video.wasRenderable = true;
          VIVIFY_DEBUG("Vivify sync: rebound persistent decoder output");
        } else if (!targetRenderable) {
          video.wasRenderable = false;
        }

        // Poll healthy decoders on the shared six-frame cadence. New/recovering
        // decoders still get checked every frame so their first frame is bound
        // as soon as Android produces it.
        if (video.hasProducedTexture && !pollVideoClock) continue;

        std::int64_t decodedFrame = -1;
        bool const hasOutputTexture = HasDecodedVideoOutput(vp, decoderPrepared, decodedFrame);
        if (hasOutputTexture) {
          if (!video.hasProducedTexture) {
            // Android can create the external texture after the original
            // output assignment. Rebind exactly when the first real
            // decoded frame appears so the screen cannot retain the black shell.
            EnsureVideoOutputBinding(video);
          }
          video.hasProducedTexture = true;
          if (decodedFrame >= 0 && decodedFrame != video.lastDecodedFrame) {
            video.lastDecodedFrame = decodedFrame;
            video.lastDecodedFrameAdvanceFrame = frame;
          }
        }

        bool const decoderIsPlaying = vp->get_isPlaying();
        bool const shouldAdvance =
            ShouldVideoAdvance(video, videoTime, playbackSpeed);

        // Commit 103: catch-up is state-based, not time-limited. Recording can
        // temporarily steal enough decoder time that a wall-clock deadline
        // expires before a heavy clip has converged. Sample only on the normal
        // shared video cadence and keep modest rate headroom until the decoder
        // is genuinely close to the song clock.
        float const frameDecodedTime = DecodedVideoTime(vp, decodedFrame);
        float const sampledDecoderTime =
            std::isfinite(frameDecodedTime)
                ? frameDecodedTime
                : static_cast<float>(vp->get_time());
        float const sampledDrift = sampledDecoderTime - videoTime;

        if (video.historicalCatchupActive && decoderIsPlaying &&
            hasOutputTexture && std::isfinite(sampledDecoderTime)) {
          bool const closeEnough =
              sampledDrift >= -kHistoricalVideoCatchupToleranceSeconds;
          if (closeEnough) {
            video.historicalCatchupStablePolls++;
          } else {
            video.historicalCatchupStablePolls = 0;
          }

          if (video.historicalCatchupStablePolls >=
              kHistoricalVideoCatchupStablePolls) {
            video.historicalCatchupActive = false;
            video.historicalCatchupStablePolls = 0;
            // Return to the authored practice rate without another seek.
            if (MeaningfulRateChange(video.lastAppliedPlaybackSpeed, playbackSpeed)) {
              try {
                vp->set_playbackSpeed(playbackSpeed);
                video.lastAppliedPlaybackSpeed = playbackSpeed;
              } catch (...) {
              }
            }
            VIVIFY_DEBUG(
                "Vivify sync: historical video catch-up converged target={} decoded={} drift={}",
                videoTime, sampledDecoderTime, sampledDrift);
          }
        } else if (!video.historicalCatchupActive && decoderIsPlaying &&
                   hasOutputTexture && shouldAdvance &&
                   std::isfinite(sampledDecoderTime) &&
                   sampledDrift < -kHistoricalVideoCatchupRearmDriftSeconds) {
          // Do not seek a healthy persistent decoder. Merely restore a small
          // amount of rate headroom. This lets Heartbeat/3 Big Shots recover
          // from recorder-induced stalls later in the song instead of free-
          // running permanently behind after startup catch-up has ended.
          video.historicalCatchupActive = true;
          video.historicalCatchupStablePolls = 0;
          VIVIFY_DEBUG(
              "Vivify sync: persistent video fell behind; rearming light catch-up target={} decoded={} drift={}",
              videoTime, sampledDecoderTime, sampledDrift);
        }

        bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
        bool const decoderStalled =
            playbackSpeed <= kVideoAggressiveRecoveryMaxRate && frameIndexAvailable &&
            hasOutputTexture && video.hasProducedTexture && shouldAdvance &&
            decoderIsPlaying &&
            frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;
        bool const missingDecodedFrame = !hasOutputTexture;

        // Recover the individual decoder only after MediaCodec has had a full
        // startup window. The previous 8-12 frame loop could repeatedly seek a
        // slow clip before it ever emitted frame 0, while a pause/resume worked
        // simply because it provided a later clean startup attempt.
        if ((missingDecodedFrame || decoderStalled) &&
            frame >= video.outputGraceUntilFrame &&
            frame >= video.nextOutputRecoveryFrame) {
          EnsureVideoOutputBinding(video);
          if (decoderIsPlaying) vp->Pause();
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          VIVIFY_DEBUG("Vivify sync: persistent decoder {} at songTime={}; applying local pause/seek/play recovery",
                       decoderStalled ? "stalled" : "has no decoded frame",
                       songTime);
          continue;
        }

        if (!pollVideoClock) continue;
        if (!decoderIsPlaying) {
          if (shouldAdvance && frame >= video.nextStartRetryFrame) {
            vp->set_time(static_cast<double>(videoTime));
            vp->Play();
            video.hasProducedTexture = false;
            video.lastDecodedFrame = -1;
            video.lastDecodedFrameAdvanceFrame = frame;
            video.outputGraceUntilFrame =
                frame + kVideoFirstFrameGraceFrames;
            video.nextStartRetryFrame = frame + 30;
            video.nextOutputRecoveryFrame =
                frame + kVideoRecoveryBackoffFrames;
            video.nextDriftCorrectionFrame =
                frame + kVideoDriftCorrectionCooldownFrames;
          }
          continue;
        }
        float const drift = static_cast<float>(vp->get_time()) - videoTime;
        // Healthy persistent Quest decoders free-run. Repeated set_time() calls
        // on MediaCodec/external textures are exactly what produced the old
        // Teto clipping/twitching. Real startup/seek/recovery paths above are
        // already the only places that are allowed to reposition this decoder.
        if (heartbeat) {
          PaperLogger.info("Vivify sync heartbeat: persistent videoTime={} target={} drift={} prepared={} playing={} texture={} targetVisible={}",
                           static_cast<float>(vp->get_time()), videoTime, drift,
                           decoderPrepared, decoderIsPlaying, hasOutputTexture,
                           targetRenderable);
        }
        continue;
      }

      if (!video.playbackTimelineStarted) {
        if (vp->get_isPlaying()) vp->Pause();
        video.wasRenderable = false;
        video.needsStartupKick = true;
        continue;
      }

      // MaterialOverride output can be detached when either the VideoPlayer's
      // GameObject or its target renderer is disabled and later re-enabled by
      // an Animator. That is the section-to-section failure seen on Quest: the
      // decoder remains prepared but the screen is black until a pause/resume.
      bool componentActive = false;
      auto videoObject = vp->get_gameObject();
      auto* videoObjectPtr = videoObject.unsafePtr();
      if (IsAlive(videoObjectPtr)) componentActive = videoObjectPtr->get_activeInHierarchy();

      bool const targetRenderable = IsVideoOutputRenderable(video);

      bool const renderable = componentActive && targetRenderable;
      if (!renderable) {
        if (video.wasRenderable) {
          VIVIFY_DEBUG("Vivify sync: video target became inactive; arming reactivation kick");
        }
        video.wasRenderable = false;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        continue;
      }

      if (!video.wasRenderable) {
        // Rebind on the exact transition back to a visible/active screen. This
        // replaces the manual pause/resume users previously needed between
        // authored video sections without restarting already healthy videos.
        video.wasRenderable = true;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (timelineJumped && video.playbackTimelineStarted) {
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (video.needsStartupKick) {
        // Re-assigning the same target is intentional: on Android this
        // recreates the output binding after an inactive->active transition.
        EnsureVideoOutputBinding(video);
        if (vp->get_isPlaying()) vp->Pause();
        vp->set_time(static_cast<double>(videoTime));
        vp->Play();
        video.needsStartupKick = false;
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: video activation/start kick (songTime={} videoTime={})",
                     songTime, videoTime);
        continue;
      }

      // As above, keep native decoder-health polling cheap once output is
      // established, while sampling startup/recovery on every frame.
      if (video.hasProducedTexture && !pollVideoClock) continue;

      // VideoPlayer.isPlaying and a non-null external-texture shell are not
      // output-health signals on Quest. Require an actual decoded frame and
      // also watch that its frame index continues to advance.
      std::int64_t decodedFrame = -1;
      bool const hasOutputTexture = HasDecodedVideoOutput(vp, decoderPrepared, decodedFrame);
      if (hasOutputTexture && !video.hasProducedTexture) {
        // First decoded frame is now real. Re-assert the output once at this
        // transition so its target receives the newly-created external
        // texture even on drivers that ignored the pre-frame binding.
        EnsureVideoOutputBinding(video);
        video.hasProducedTexture = true;
      }
      if (hasOutputTexture && decodedFrame >= 0 &&
          decodedFrame != video.lastDecodedFrame) {
        video.lastDecodedFrame = decodedFrame;
        video.lastDecodedFrameAdvanceFrame = frame;
      }

      bool const shouldAdvance =
          ShouldVideoAdvance(video, videoTime, playbackSpeed);
      bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
      bool const decoderIsPlaying = vp->get_isPlaying();
      bool const decoderStalled =
          playbackSpeed <= kVideoAggressiveRecoveryMaxRate && frameIndexAvailable &&
          hasOutputTexture && video.hasProducedTexture && shouldAdvance &&
          decoderIsPlaying &&
          frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;

      if ((!hasOutputTexture || decoderStalled) &&
          frame >= video.outputGraceUntilFrame &&
          frame >= video.nextOutputRecoveryFrame) {
        EnsureVideoOutputBinding(video);
        if (decoderIsPlaying) vp->Pause();
        vp->set_time(static_cast<double>(videoTime));
        vp->Play();
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: recovering {} video output (songTime={} videoTime={})",
                     decoderStalled ? "stalled" : "black", songTime,
                     videoTime);
        continue;
      }

      if (!pollVideoClock) continue;
      if (!decoderIsPlaying) {
        if (shouldAdvance && frame >= video.nextStartRetryFrame) {
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          VIVIFY_DEBUG("Vivify sync: retrying prepared video start (songTime={} videoTime={})",
                       songTime, videoTime);
        }
        continue;
      }

      float const drift = static_cast<float>(vp->get_time()) - videoTime;
      if (!video.historicalCatchupActive &&
          playbackSpeed <= kVideoAggressiveRecoveryMaxRate &&
          std::abs(drift) > kVideoDriftToleranceSeconds &&
          frame >= video.nextDriftCorrectionFrame) {
        vp->set_time(static_cast<double>(videoTime));
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
      }
      if (heartbeat) {
        PaperLogger.info("Vivify sync heartbeat: videoTime={} target={} songTime={} startTime={} drift={} speed={} prepared={} playing={} renderable={} texture={}",
                         static_cast<float>(vp->get_time()), videoTime, songTime, synced.startTime,
                         drift, playbackSpeed, decoderPrepared, decoderIsPlaying,
                         renderable, hasOutputTexture);
      }
    }
  }
  // Video/seek synchronization owns the callback clock. Keeping this separate
  // from prefab animation timing preserves the stable decoder behavior while
  // allowing visuals to follow AudioTimeSyncController without a phase delay.
  _lastSyncSongTime = songTime;
}

bool Runtime::IsReduceDebrisEnabled() {

  if (!_reduceDebrisCached) {
    _reduceDebrisCached = true;
    _reduceDebris = false;
    auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
    if (IsManagedAlive(playerDataModel)) {
      auto* playerData = playerDataModel->get_playerData();
      if (playerData != nullptr) {
        auto* settings = playerData->get_playerSpecificSettings();
        if (settings != nullptr) {
          _reduceDebris = settings->get_reduceDebris();
        }
      }
    }
    VIVIFY_DEBUG("Vivify: Reduce Debris player option = {} (custom debris {})", _reduceDebris,
                 _reduceDebris ? "disabled" : "enabled");
  }
  return _reduceDebris;
}

bool Runtime::IsLeftHanded() {
  if (_leftHandedCached) return _leftHanded;

  _leftHandedCached = true;
  _leftHanded = false;
  auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
  if (IsAlive(playerDataModel)) {
    auto* playerData = playerDataModel->get_playerData();
    if (playerData != nullptr) {
      auto* settings = playerData->get_playerSpecificSettings();
      if (settings != nullptr) _leftHanded = settings->get_leftHanded();
    }
  }
  VIVIFY_DEBUG("Vivify prefab mirroring: left-handed mode={}", BoolText(_leftHanded));
  return _leftHanded;
}

UnityEngine::Transform* Runtime::EnsureMirroredPrefabParent() {
  if (!IsLeftHanded()) return nullptr;
  if (!IsAlive(_mirroredPrefabParent)) {
    _mirroredPrefabParent = UnityEngine::GameObject::New_ctor(u"VivifyLeftHandPrefabParent");
    if (!IsAlive(_mirroredPrefabParent)) return nullptr;
    _mirroredPrefabParent->get_transform()->set_localScale(UnityEngine::Vector3(-1.0f, 1.0f, 1.0f));
  }
  return _mirroredPrefabParent->get_transform().unsafePtr();
}

void Runtime::SetPauseMenuActive(bool active) {
  _pauseMenuRequested = active;
  ApplyPauseState();
}

void Runtime::SetApplicationPaused(bool paused) {
  _applicationPaused = paused;
  ApplyPauseState();
}

void Runtime::SetApplicationFocused(bool focused) {
  _applicationFocused = focused;
  ApplyPauseState();
}

void Runtime::ApplyPauseState() {
  bool const active = _pauseMenuRequested || _applicationPaused || !_applicationFocused;
  if (_currentBeatmapData == nullptr) {
    _pauseMenuActive = false;
    return;
  }
  if (_pauseMenuActive == active) return;
  _pauseMenuActive = active;
  VIVIFY_DEBUG("Vivify suspension {}: menu={} applicationPaused={} applicationFocused={} syncedObjects={} secondaryCameras={}",
               active ? "entered" : "left", _pauseMenuRequested, _applicationPaused,
               _applicationFocused, _syncedObjects.size(), _secondaryCameras.size());
  if (active) {
    // Suspend Unity-driven prefab time immediately. Runtime::Update stops as
    // soon as the lifecycle is suspended, so deferring this to
    // UpdatePrefabAnimationSpeed lets Animator and ParticleSystem components
    // keep advancing behind the pause or Quest system menu.
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(0.0f);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, 0.0f);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, true);
      }
      for (auto& video : synced.videoPlayers) {
        auto* vp = video.player;
        if (IsManagedAlive(vp) && vp->get_isPlaying()) vp->Pause();
        video.needsStartupKick = true;
      }
    }
    _lastAppliedSyncSpeed = 0.0f;

    _lifecycle.Suspend();

    if (_cameraApplier != nullptr && UnityEngine::Object::op_Implicit_bool(_cameraApplier)) {
      _cameraApplier->set_enabled(false);
    }
    // A secondary camera can be disabled intentionally (for example when it
    // has no color/depth target). Remember that state exactly; blindly enabling
    // every camera on resume can render an un-targeted helper into the headset.
    RestoreSecondaryCullingLayers();
    RemoveMidRenderCommandBuffers();
    for (auto& [name, cam] : _secondaryCameras) {
      cam.enabledBeforePause = IsAlive(cam.camera) && cam.camera->get_enabled();
      if (IsAlive(cam.camera)) cam.camera->set_enabled(false);
    }

    RestoreGlobalProperties();

    // Keep authored render and QualitySettings values alive through the pause
    // menu. Restoring antiAliasing here and reapplying it immediately after an
    // Android XR resume can recreate the eye render targets while OpenXR is
    // reattaching its swapchain. The captured XR-resume freeze stopped on exactly
    // that resume path. Desktop Vivify also keeps these values until runtime
    // disposal, so teardown/restart remains the only place that restores them.
    VIVIFY_DEBUG("Vivify pause: preserving {} authored render setting(s) across XR suspend",
                 _currentRenderSettings.size());

    _pausedMaterialAnimations = std::move(_materialAnimations);
    _pausedGlobalAnimations = std::move(_globalAnimations);
    _pausedAnimatorAnimations = std::move(_animatorAnimations);
    _pausedRenderSettingAnimations = std::move(_renderSettingAnimations);
    _materialAnimations.clear();
    _materialPropertyFrameOverrides.clear();
    _globalAnimations.clear();
    _animatorAnimations.clear();
    _renderSettingAnimations.clear();
  } else {
    for (auto& [name, cam] : _secondaryCameras) {
      if (IsAlive(cam.camera)) cam.camera->set_enabled(cam.enabledBeforePause);
      cam.enabledBeforePause = false;
    }
    VIVIFY_DEBUG("Vivify resume checkpoint: secondary cameras restored");

    ReapplyCurrentGlobalProperties();
    VIVIFY_DEBUG("Vivify resume checkpoint: global shader state restored; authored render settings preserved");
    _materialAnimations = std::move(_pausedMaterialAnimations);
    _globalAnimations = std::move(_pausedGlobalAnimations);
    _animatorAnimations = std::move(_pausedAnimatorAnimations);
    _renderSettingAnimations = std::move(_pausedRenderSettingAnimations);
    _pausedMaterialAnimations.clear();
    _pausedGlobalAnimations.clear();
    _pausedAnimatorAnimations.clear();
    _pausedRenderSettingAnimations.clear();
    VIVIFY_DEBUG("Vivify resume checkpoint: authored animations restored");

    float resumeSpeed = 0.0f;
    if (IsManagedAlive(_audioTimeSyncController)) {
      float const authoredSpeed = _audioTimeSyncController->get_timeScale();
      if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) resumeSpeed = authoredSpeed;
    }
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(resumeSpeed);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, resumeSpeed);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, resumeSpeed <= 0.0f);
      }
      for (auto& video : synced.videoPlayers) {
        video.needsStartupKick = true;
        video.nextStartRetryFrame = 0;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = 0;
        video.nextDriftCorrectionFrame = 0;
      }
      synced.nextVideoClockPollFrame = 0;
    }

    _lifecycle.Resume();
    // Force a fresh callback-clock sample and reapply the practice speed on
    // the first resumed frame. Otherwise a long Android sleep can leave
    // Animator/ParticleSystem components at the pause speed of zero.
    _songTimeCacheFrame = -1;
    _lastSyncSongTime = -1.0f;
    _lastVisualSyncSongTime = -1.0f;
    _syncClockStallFrames = 0;
    _syncClockHasAdvanced = false;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    VIVIFY_DEBUG("Vivify resume checkpoint: lifecycle active; refreshing camera components");
    if (!_isResetting) RefreshCameraComponents(true);
    VIVIFY_DEBUG("Vivify resume complete: songTime={} syncedObjects={} secondaryCameras={} renderSettingsPreserved={}",
                 CurrentSongTime(), _syncedObjects.size(), _secondaryCameras.size(),
                 _currentRenderSettings.size());
  }
}

bool Runtime::ShouldDeferNaturalCompletionTransition() const {
  if (_currentBeatmapData == nullptr || !IsManagedAlive(_audioTimeSyncController) ||
      _postEffects.empty()) {
    return false;
  }

  float const songTime = _audioTimeSyncController->get_songTime();
  float const songEndTime = _audioTimeSyncController->get_songEndTime();
  if (!std::isfinite(songTime) || !std::isfinite(songEndTime) || songEndTime <= 0.0f) {
    return false;
  }

  // Scene dismissal for a completed song can start slightly before the audio
  // clock reaches its terminal sample. Keep this window deliberately small so
  // pause-menu exits, restarts and arbitrary scene transitions retain the
  // established crash-safe immediate teardown.
  float const remaining = songEndTime - songTime;
  return remaining <= 0.35f && remaining >= -0.10f;
}

void Runtime::HandleScenesWillDismiss() {
  if (_currentBeatmapData == nullptr && _lifecycle.Phase() == RuntimePhase::Dormant &&
      _activeSabers.empty() && _cameraApplier == nullptr &&
      _secondaryCameras.empty() && _livePrefabs.empty()) {
    return;
  }

  if (ShouldDeferNaturalCompletionTransition()) {
    // Preserve the authored final post-processing/material state, but keep the
    // crash-order fix: Vivify-owned MediaCodec/VideoPlayer decoders are still
    // stopped before Unity starts destroying their scene render targets.
    for (auto& synced : _syncedObjects) {
      ReleaseSyncedVideos(synced, false);
    }
    _naturalCompletionTransitionPending = true;
    VIVIFY_DEBUG(
        "Vivify deferring natural-completion reset until gameplay audio retires: songTime={} songEndTime={} postEffects={}",
        _audioTimeSyncController->get_songTime(),
        _audioTimeSyncController->get_songEndTime(), _postEffects.size());
    return;
  }

  VIVIFY_DEBUG("Vivify retiring gameplay session before scene dismissal");
  ResetRuntime(ResetMode::EarlySceneTransition);
}

void Runtime::HandleGameplayRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  VIVIFY_DEBUG("Vivify retiring gameplay session before restart");
  ResetRuntime(ResetMode::LiveScene);
}

bool Runtime::IsCameraApplierCurrent(CameraApplier* applier) const {
  if (!IsAlive(applier) || applier != _cameraApplier ||
      !_lifecycle.CanRender(applier->sessionGeneration)) {
    return false;
  }
  auto gameObject = applier->get_gameObject();
  return IsAlive(gameObject.unsafePtr()) && gameObject.unsafePtr() == _cameraApplierGO;
}

bool Runtime::BeginCameraRender(CameraApplier* applier) {
  return IsCameraApplierCurrent(applier) &&
         _lifecycle.TryEnterRender(applier->sessionGeneration);
}

void Runtime::EndCameraRender(CameraApplier* applier) {
  (void)applier;
  _lifecycle.LeaveRender();

  // Do not destroy/release render resources from EndCameraRender. The previous
  // replay-memory experiment did that during the natural-completion handoff and
  // did not fix Aether. Resource ownership returns to the established reset
  // path; this scope only closes the lifecycle render-depth pairing.

  FinishPendingReset();
}

bool Runtime::ShouldSuppressOriginalImageEffect(
    GlobalNamespace::ImageEffectController* controller) const {
  if (!IsAlive(controller) || !IsCameraApplierCurrent(_cameraApplier) ||
      !_cameraApplier->get_enabled() || !_cameraApplier->hasMainEffect) {
    return false;
  }
  auto controllerGO = controller->get_gameObject();
  return IsAlive(controllerGO.unsafePtr()) && controllerGO.unsafePtr() == _cameraApplierGO;
}

void Runtime::OnCameraApplierDestroyed(CameraApplier* applier) {
  RemoveMidRenderCommandBuffers(applier);
  if (_cameraApplier != applier) return;
  _cameraApplier = nullptr;
  _cameraApplierGO = nullptr;
}

void Runtime::RefreshMultipassRendering() {
  auto mainCam = UnityEngine::Camera::get_main();
  auto mainCamGO = IsAlive(mainCam.unsafePtr()) ? mainCam->get_gameObject().unsafePtr() : nullptr;
  RefreshMultipassRendering(mainCamGO);
  RefreshLoadedMaterialStereoKeywords();
}

void Runtime::RefreshIsolationSettings() {
  if (GetDisableAllBlits()) {
    if ((!_preEffects.empty() || !_postEffects.empty() || HasMidRenderEffects()) && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: clearing active blits (Blit effects disabled) pre={} post={}",
                       _preEffects.size(), _postEffects.size());
    }
    _preEffects.clear();
    _postEffects.clear();
    for (auto& bucket : _midEffects) bucket.clear();
    DestroyCameraApplier();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
  } else if (GetDisableBeat0FilmgrainBlit()) {
    UpdateBlitEffects();
  }

  if (GetDisableCreateCameraDepth()) {
    if (!_secondaryCameras.empty() && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: releasing secondary cameras count={}", _secondaryCameras.size());
    }
    for (auto& [name, camera] : _secondaryCameras) {
      ReleaseSecondaryCameraData(camera);
    }
    _secondaryCameras.clear();
    for (auto it = _cameraProperties.begin(); it != _cameraProperties.end();) {
      if (it->first != kMainCameraId) {
        it = _cameraProperties.erase(it);
      } else {
        it++;
      }
    }
  } else {
    // Re-apply stored secondary-camera properties after an isolation setting
    // changes. The culling controller owns temporary layer restoration.
    for (auto& [name, camera] : _secondaryCameras) {
      if (!IsAlive(camera.camera)) continue;
      ApplySecondaryCameraProperties(camera);
      ApplyCameraGameObjectProperties(camera.camera, camera.properties);
    }
  }

  RefreshCameraComponents(_currentBeatmapData != nullptr && !_isResetting && !_pauseMenuActive);
}

void Runtime::ResetRuntime(ResetMode mode) {
  auto const resetRank = [](ResetMode candidate) {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return 0;
      case ResetMode::LiveScene: return 1;
      case ResetMode::EarlySceneTransition: return 2;
      case ResetMode::LateSceneTransition: return 3;
    }
    return 3;
  };
  auto const resetName = [](ResetMode candidate) -> char const* {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return "gameplay-preparation";
      case ResetMode::LiveScene: return "live-scene";
      case ResetMode::EarlySceneTransition: return "early-transition";
      case ResetMode::LateSceneTransition: return "late-transition";
    }
    return "unknown";
  };

  [[maybe_unused]] auto const retiredGeneration = _lifecycle.BeginRetirement();
  if (_lifecycle.RenderDepth() != 0) {
    // A scene transition may advance while an image-effect callback is still
    // unwinding. By the time the deferred reset executes, old scene wrappers
    // can already be native-dead. Escalate transition cleanup to the pointer-
    // free late mode rather than replaying scene-touching teardown later.
    // LiveScene is the only reset that is guaranteed to keep using the same
    // gameplay scene after the render callback returns. GameplayPreparation
    // can be a new replay/practice session whose old scene is already leaving,
    // so defer it as pointer-free late retirement just like scene transitions.
    ResetMode const deferredMode =
        mode == ResetMode::LiveScene ? ResetMode::LiveScene
                                     : ResetMode::LateSceneTransition;
    if (!_pendingResetMode.has_value() ||
        resetRank(deferredMode) > resetRank(_pendingResetMode.value())) {
      _pendingResetMode = deferredMode;
    }
    _isResetting = true;
    VIVIFY_DEBUG("Vivify deferred {} reset as {} until {} active render scope(s) leave",
                 resetName(mode), resetName(deferredMode), _lifecycle.RenderDepth());
    return;
  }

  VIVIFY_DEBUG("Vivify ResetRuntime: mode={} livePrefabs={} preloaded={} synced={} secondaryCameras={} declaredTextures={} assets={}",
               resetName(mode), _livePrefabs.size(), _instantiatePrefabs.size(), _syncedObjects.size(),
               _secondaryCameras.size(), _declaredTextures.size(), _assets.size());
  _isResetting = true;
  bool const canTouchSceneObjects = mode != ResetMode::LateSceneTransition;
  bool const preserveGameplayScene =
      mode == ResetMode::GameplayPreparation || mode == ResetMode::LiveScene;
  bool const preserveBundleVideoWarmups =
      mode == ResetMode::GameplayPreparation;

  // Persistent decoder proxies live under VivifyRuntime, while their authored
  // renderer/RenderTexture targets live in the gameplay scene. Stop and retire
  // the owned decoders before any scene target is destroyed or released. The
  // old ordering tore scene outputs down first and only then stopped MediaCodec,
  // which could race practice-speed/restart teardown on Quest.
  for (auto& synced : _syncedObjects) ReleaseSyncedVideos(synced, false);
  _syncedObjects.clear();

  if (canTouchSceneObjects) {
    // This path is used while the gameplay scene is still alive (for example a
    // practice-mode backward seek), so authored state can be restored normally.
    DestroyCameraApplier();
    RestoreMaterialProperties();
    RestoreGlobalProperties();
    RestoreAllVisualReplacements();
    RestoreMainCameraOriginals();

    std::unordered_set<UnityEngine::GameObject*> destroyed;
    for (auto& [id, prefab] : _livePrefabs) {
      if (prefab.gameObject == nullptr) continue;
      for (auto const& track : prefab.tracks) track.UnregisterGameObject(prefab.gameObject);
      if (destroyed.emplace(prefab.gameObject).second && IsAlive(prefab.gameObject)) {
        UnityEngine::Object::Destroy(prefab.gameObject);
      }
    }
    for (auto& [eventData, instantiate] : _instantiatePrefabs) {
      if (instantiate.instance != nullptr && destroyed.emplace(instantiate.instance).second &&
          IsAlive(instantiate.instance)) {
        UnityEngine::Object::Destroy(instantiate.instance);
      }
      instantiate.instance = nullptr;
    }
    if (IsAlive(_mirroredPrefabParent)) {
      UnityEngine::Object::Destroy(_mirroredPrefabParent);
    }

    for (auto& [name, dt] : _declaredTextures) ReleaseDeclaredTextureData(dt);
    for (auto& [name, cam] : _secondaryCameras) ReleaseSecondaryCameraData(cam);
    RemoveMidRenderCommandBuffers();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
    RestoreRenderSettings();

    if (IsAlive(_multipassController)) {
      _multipassController->set_enabled(false);
      UnityEngine::Object::Destroy(_multipassController);
    }
  } else {
    // Scene transitions are deliberately pointer-free. Crash tombstones showed
    // stale wrappers reaching RenderTexture::Release, Object::Destroy,
    // Renderer.enabled, and Behaviour.enabled after leaving a song. Only static
    // shader bindings are cleared here; Unity owns destruction of the old scene.
    for (auto const& [name, data] : _declaredTextures) {
      UnityEngine::Shader::SetGlobalTexture(data.propertyId, static_cast<UnityEngine::Texture*>(nullptr));
    }
    for (auto const& [name, data] : _secondaryCameras) {
      if (data.texturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.texturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
      if (data.depthTexturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.depthTexturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    // Static shader globals are safe to restore during a late transition as
    // long as we do not dereference texture objects from the old scene. Scalars
    // and vectors are plain values; old texture bindings are explicitly nulled.
    for (auto const& [propertyId, value] : _savedGlobalProperties) {
      if (std::holds_alternative<UnityEngine::Texture*>(value)) {
        UnityEngine::Shader::SetGlobalTexture(propertyId, static_cast<UnityEngine::Texture*>(nullptr));
      } else if (std::holds_alternative<UnityEngine::Color>(value)) {
        UnityEngine::Shader::SetGlobalColor(propertyId, std::get<UnityEngine::Color>(value));
      } else if (std::holds_alternative<float>(value)) {
        UnityEngine::Shader::SetGlobalFloat(propertyId, std::get<float>(value));
      } else if (std::holds_alternative<UnityEngine::Vector4>(value)) {
        UnityEngine::Shader::SetGlobalVector(propertyId, std::get<UnityEngine::Vector4>(value));
      }
    }
    for (auto const& [keyword, enabled] : _savedGlobalKeywords) {
      if (enabled) UnityEngine::Shader::EnableKeyword(StringW(keyword));
      else UnityEngine::Shader::DisableKeyword(StringW(keyword));
    }

    RestoreRenderSettings(true);
    _savedMaterialStates.clear();

    // Do not Dispose/Destroy transition-owned native objects. Clear every raw
    // pointer so the persistent VivifyRuntime behaviour cannot touch them on a
    // later menu frame or when another song is selected.
    _cameraApplier = nullptr;
    _cameraApplierGO = nullptr;
    _multipassController = nullptr;
    _lastMainCameraGO = nullptr;
    _mainCameraWasUnavailable = false;
    _midCommandBufferCamera = nullptr;
    _midCommandBufferOwner = nullptr;
    _activeMidCommandBuffers.clear();
    _midSelfBlitTemps.clear();
    _midRenderCommandCache.Invalidate();
    _midMainRT = nullptr;
    _midScratchRT = nullptr;
    _mainBlitTexture = nullptr;
    _scratchBlitTexture = nullptr;
    ReleaseImageBlitCommandBuffer(false);
    SetMultipassShaderState(false);
    _beatmapCallbacksController = nullptr;
  }

  _livePrefabs.clear();
  _instantiatePrefabs.clear();
  _deferredPrefabPrewarms.clear();
  if (!preserveBundleVideoWarmups) ReleaseBundleVideoWarmups();
  _blitMaterialValidCache.clear();
  _blitMaterials.clear();
  _warnedInvalidBlitPasses.clear();
  _loggedBlitStereoMaterials.clear();
  _materialAnimations.clear();
  _materialPropertyFrameOverrides.clear();
  _materialPropertySequence = 0;
  _globalAnimations.clear();
  _animatorAnimations.clear();
  _renderSettingAnimations.clear();
  _pausedMaterialAnimations.clear();
  _pausedGlobalAnimations.clear();
  _pausedAnimatorAnimations.clear();
  _pausedRenderSettingAnimations.clear();
  _savedMaterialStates.clear();
  _savedGlobalProperties.clear();
  _savedGlobalKeywords.clear();
  _currentGlobalProperties.clear();
  _currentGlobalKeywords.clear();
  _repairedMaterials.clear();
  _genericFallbackMaterials.clear();
  if (!preserveBundleVideoWarmups) {
    // Bundle asset objects are preload-owned, not gameplay-scene objects. Keep
    // them through the menu->gameplay preparation handoff so LoadMainBundle
    // does not synchronously load the whole bundle twice. Live/restart/scene
    // retirement still invalidates the cache exactly as before.
    _assets.clear();
    _assetsByName.clear();
    _ambiguousAssetAliases.clear();
    _supportedShadersByName.clear();
    _bundleAssetCacheReady = false;
  }
  _missingAssetKeys.clear();
  _missingInstantiatePrefabAssets.clear();
  _catchUpAppliedCustomEvents.clear();
  _deferredStartupPostProcessingEvents.clear();
  _deferredSaberVisualsUntilFrame = -1;
  _saberVisualRetryUntilFrame = -1;
  _lastSaberIntegrityFrame = -1000;
  _warnedInvalidBeatmapData = false;
  _warnedStartupDescriptorWait = false;
  _postProcessingReadyFrame = -1;
  _nextBeatmapPrepareProbeFrame = 0;
  _nextSyncedObjectPurgeFrame = 0;
  _declaredTextures.clear();
  _secondaryCameras.clear();
  _preEffects.clear();
  _postEffects.clear();
  for (auto& bucket : _midEffects) bucket.clear();
  _midRenderCommandCache.Invalidate();
  _hasMainDescriptor = false;
  _cachedMainVrUsage = -1;
  _savedRenderSettings.clear();
  _currentRenderSettings.clear();
  _assignedPrefabs.clear();
  InvalidateAssignedPrefabLookup();
  _activeDebrisPrefabStack.clear();
  _lastCutDebrisPrefabs.clear();
  if (!preserveGameplayScene) {
    _activeSabers.clear();
    _activeNoteControllers.clear();
  } else {
    // PrepareBeatmap and practice/restart resets run while the same gameplay
    // scene (and SaberModelController objects) are still alive. Erasing this
    // list made AssignObjectPrefab at beat 0 a no-op until pausing/restarting
    // happened to reconstruct the saber hierarchy.
    PurgeInvalidActiveSabers();
    for (auto it = _activeNoteControllers.begin(); it != _activeNoteControllers.end();) {
      if (!IsAlive(*it)) {
        it = _activeNoteControllers.erase(it);
      } else {
        ++it;
      }
    }
  }
  _noteReplacements.clear();
  _saberReplacements.clear();
  _debrisReplacements.clear();
  _cameraProperties.clear();
  _mainCameraPropsDirty = false;
  _mainCamOriginalDepthMode.reset();
  _mainCamOriginalClearFlags.reset();
  _mainCamOriginalBackgroundColor.reset();
  _mirroredPrefabParent = nullptr;

  if (preserveGameplayScene && _mainBundle != nullptr && !UnityEngine::Object::op_Implicit_bool(_mainBundle)) {
    _mainBundle = nullptr;
    _preloadedBundlePath.clear();
  }
  if (!preserveGameplayScene) _beatmapCallbacksController = nullptr;
  _currentBeatmapData = nullptr;
  _beatmapAD = nullptr;
  _audioTimeSyncController = nullptr;
  _lastSongTime = -1.0f;
  _lastSyncSongTime = -1.0f;
  _lastVisualSyncSongTime = -1.0f;
  _syncClockStallFrames = 0;
  _syncClockHasAdvanced = false;
  _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  _lastQuestPerformanceFrame = -1000;
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
  _songTimeCacheFrame = -1;
  _songTimeCache = 0.0f;
  _pauseMenuRequested = false;
  _applicationPaused = false;
  _applicationFocused = true;
  _pauseMenuActive = false;
  _reduceDebrisCached = false;
  _reduceDebris = false;
  _leftHandedCached = false;
  _leftHanded = false;
  _preparingGeneration = 0;
  _naturalCompletionTransitionPending = false;
  _pendingResetMode.reset();
  [[maybe_unused]] bool const retired = _lifecycle.CompleteRetirement();
  _isResetting = false;
}

void Runtime::FinishPendingReset() {
  if (_lifecycle.RenderDepth() != 0 || !_pendingResetMode.has_value()) return;
  auto const mode = _pendingResetMode.value();
  _pendingResetMode.reset();
  _isResetting = false;
  ResetRuntime(mode);
}

}
