# Performance-first Luminescent stereo profile

This build is based directly on the Aether replay/session-fix source that eliminated the repeat/timeline crash.

Only the Luminescent stereo tradeoff changes:
- `Hidden/Old` (3 Big Shots) retains the proven per-eye Tex2D compatibility bridge.
- Nasafrasa Glitch/Pixelate no longer opt into that bridge. They use the normal XR compositor path instead.
- On Quest Multiview, Luminescent may mirror one eye. This is intentional in this profile because the per-eye bridge was confirmed to bring the visible lag back.

Aether replay/session identity fixes, visual animation clock fixes, 3BS freeze compatibility, video/saber/Aether lifecycle behavior, and all other source stay unchanged.
