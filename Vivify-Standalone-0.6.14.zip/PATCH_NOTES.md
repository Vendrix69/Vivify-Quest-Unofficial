# Q2 Turbo 3x — crash-order + 3BS freeze-frame + Pixelate restore

- Keeps the validated 3.0x high-speed catch-up controller unchanged.
- Restart/practice-speed teardown now stops and retires Vivify-owned VideoPlayer decoders before scene renderer/RenderTexture targets are destroyed.
- Removes the failed consecutive-legacy Lumi 2D-chain experiment so Pixelate returns to the proven Commit-109 per-eye path. The existing Lumi mirror fix remains; the old short overlap blackout is not claimed fixed in this build.
- 3 Big Shots `Hidden/Old` now explicitly receives `_Old*` CreateScreenTexture captures as real per-eye Tex2D globals. This does not depend on `Material.HasProperty`, because the legacy shader can consume those globals without exposing them in the material Properties block.
- No new seeks, retries, watchdogs, decoder topology rules, or sync branches.

# Clean Baseline — Crash Safety + Luminescent Handoff

This build stays on the validated Commit-103 video baseline. It does not change seek, catch-up, playback-rate, decoder-sharing, or warmup ownership behavior.

## Crash safety
- Vivify-owned gameplay VideoPlayers call `Stop()` immediately before their decoder GameObject is destroyed.
- Duplicate decoders retired during same-timeline sharing also stop before destruction.
- Menu warmup decoders stop before discarded warmup objects are destroyed.
- This targets the rare first-load / practice-speed-change MediaCodec teardown race without touching the ~3 second synchronization behavior.

## Luminescent blackout before Pixelate
- The existing Commit-109 per-eye Tex2D bridge remains unchanged for a single legacy fullscreen effect.
- When two or more legacy main-camera passes overlap (the authored Glitch -> Pixelate handoff at the end of Luminescent), Quest now keeps the entire chain in per-eye 2D ping-pong render targets.
- The final image is copied back to the XR texture-array eye only once after the chain.
- This avoids an XR-array write/read round trip between Glitch and Pixelate while preserving the already-fixed stereo orientation.

## Intentionally unchanged
- Commit-103 video synchronization and historical catch-up.
- 3 Big Shots declared `_Old*` screen-texture handling.
- YOU/reset-state hygiene.
- Teto/Aether/Flux-related rendering paths.


## Fast safe video catch-up
High-speed historical video catch-up keeps the Commit-103 state machine and raises only the >125% rate headroom from +0.35x to +0.50x (absolute cap 2.50x). No extra seeks, retries, decoder restarts, or per-frame polling were added.


## Q2 turbo catch-up experiment
High-speed historical video catch-up now uses up to +1.00x rate headroom with an absolute 3.00x decoder cap. The existing Quest VideoPlayer path already enables skipOnDrop, so intermediate presentation frames may be discarded while catching up. No additional seeks, retries, polling, restart logic, or decoder ownership changes were added. Low-speed catch-up remains unchanged.

## Stable-baseline targeted merge (2026-09-20)

Built directly on the user-confirmed stable Q2Turbo3x baseline.

- Keeps Luminescent's existing Glitch/Pixelate per-eye Tex2D bridge unchanged so the confirmed mirror fix is preserved.
- Restores the faster 0.5.5 outer image-effect ownership path: Vivify renders Beat Saber's MainEffectSO directly between pre/post chains and suppresses the duplicate ImageEffectController pass on the owned gameplay camera.
- Prevents equivalent late-song CustomBeatmapData wrapper swaps from resetting Vivify and replaying historical events, targeting Luminescent's end blackout without changing material-property ownership semantics.
- Upgrades 3 Big Shots Hidden/Old to private per-eye material clones with real Tex2D _Old* captures and gives material-free _Old* capture Blits one extra render frame on Quest.
- Does not import the 0.5.5 material-animation rollback; Flare In You keeps the stable baseline's newer same-frame/endpoint ownership behavior.

## Clean natural-completion blackout fix (2026-09-20)

- Starts from the exact user-confirmed build where Luminescent lag, mirroring, Pixelate and 3 Big Shots freeze are working and only the final blackout remains.
- Does not modify Blit ordering, stereo/per-eye routing, MainEffect ownership, material animation semantics, or 3BS.
- The earlier `GameScenesManager::ScenesTransitionCoroutine` crash-hardening hook reset the entire Vivify runtime as soon as gameplay scene dismissal began. Near Luminescent's natural song end this occurs before the final Pixelate callback, so the next callback re-prepares the beatmap and replays historical stateful events in one frame.
- Natural completion with a live post-effect now defers only the state-clearing reset during the final 0.35 seconds of the gameplay audio clock. Vivify-owned video decoders are still stopped immediately so the existing decoder/render-target teardown safety is preserved.
- Mid-song exits, restarts and non-completion scene transitions keep the previous immediate reset behavior.
- Once the gameplay AudioTimeSyncController retires, the existing late-transition reset runs normally.


## Clean performance/timing pass — correct visual baseline (2026-09-23)

- Rebased on the CleanCompletion source where Luminescent mirroring/Pixelate, the 3 Big Shots freeze-frame path, and the final natural-completion blackout fix are all present.
- Removed Vivify's custom file-log sink and compile-time disabled debug logging. Normal warnings/errors remain in the platform logger.
- Prefab prewarming is hard-disabled and its per-frame update is not run. InstantiatePrefab metadata is still registered normally; real instances are created on authored events.
- Kept `VivifyPostProcessing.cpp` and `VivifyComponents.cpp` byte-identical to the known-good baseline.
- Kept material/global/render-setting animation timing byte-for-byte baseline because those values can feed fullscreen Blit shaders.
- Applied the low-latency clock/catch-up fix only to `SetAnimatorProperty`, which cannot alter Blit material state.
