# Recovery build

This build rolls back the unsafe replay-cleanup experiment and restores the known-good baseline post-processing bridge byte-for-byte (except the new material-animation clock argument).

Changes from the known-good baseline:
- Visual Animator/Animation + ordinary scene material timing uses the audible AudioTimeSyncController clock.
- Blit material animation stays on the callback clock.
- Lumi Glitch/Pixelate + Hidden/Old use the exact baseline per-eye stereo bridge.
- Natural completion releases Vivify-owned render resources only after the final camera render has completed, before the pointer-free MainMenu reset. No stale-wrapper probing is performed from LevelWasSelected/LateSceneTransition.
- The risky same-level AssetBundle unload experiment is removed.
