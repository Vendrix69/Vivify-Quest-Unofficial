# Aether replay / practice-timeline crash fix

This patch targets the deterministic crash after one Aether run when the same chart is started again, including a different practice timeline.

Root lifecycle bug fixed:
- Beat Saber may reuse the same `CustomBeatmapData` / `CustomEventData` objects across separate gameplay runs.
- Vivify previously treated matching beatmap/event pointers as proof that the current beatmap was still the same live session, even when `BeatmapCallbacksController` had changed.
- That could attach the second run to the retired first-run generation instead of fully preparing a new Vivify session.

Changes:
- `BeatmapCallbacksController*` is now the gameplay-session identity. Wrapper-only rebinds are accepted only while the same controller is still active.
- A new controller with stale prior beatmap state uses pointer-free `LateSceneTransition` retirement instead of scene-touching `GameplayPreparation` cleanup.
- If previous camera rendering is still unwinding, preparation aborts until the pending retirement completes; a new generation is never started on top of a retiring one.
- Deferred `GameplayPreparation` is escalated to pointer-free late retirement when a render scope is active. `LiveScene` restart remains the only scene-touching deferred mode.
- Removes the failed natural-completion RenderTexture release experiment from `EndCameraRender`; resource destruction returns to the established reset path.

Unchanged:
- Luminescent/3BS post-processing implementation.
- Visual-clock animation fix.
- Video synchronization/catch-up logic.
- Aether particle/saber/rendering implementation.
